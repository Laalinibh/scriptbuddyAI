#!/usr/bin/env python3
"""
Final comprehensive test of AI Movie Script Generator
Tests all components with Netflix engagement data
"""

from netflix_data_processor import NetflixEngagementProcessor
from data_analyzer import NetflixDataAnalyzer
from psychological_profiler import PsychologicalProfiler
from script_generator import ScriptGenerator
import pandas as pd

def test_complete_workflow():
    """Test the complete Netflix to script generation workflow"""
    
    print("=== AI Movie Script Generator - Complete Test ===\n")
    
    # Step 1: Load and process Netflix engagement data
    print("1. Loading Netflix engagement data...")
    processor = NetflixEngagementProcessor()
    netflix_data = processor.load_netflix_engagement_data(
        'attached_assets/What_We_Watched_A_Netflix_Engagement_Report_2024Jan-Jun_1749309553207.xlsx'
    )
    print(f"   ✓ Loaded {len(netflix_data)} viewing records")
    print(f"   ✓ Data columns: {list(netflix_data.columns)}")
    
    # Step 2: Analyze viewing patterns
    print("\n2. Analyzing viewing patterns...")
    analyzer = NetflixDataAnalyzer(netflix_data)
    patterns = analyzer.analyze_viewing_patterns()
    print(f"   ✓ Generated {len(patterns)} viewing pattern metrics")
    
    # Step 3: Create user profiles
    print("\n3. Creating user profiles...")
    user_profiles = analyzer.create_user_profiles()
    print(f"   ✓ Created profiles for {len(user_profiles)} users")
    print(f"   ✓ Profile features: {list(user_profiles.columns)}")
    
    # Step 4: Perform user clustering
    print("\n4. Performing user clustering...")
    clustering_results = analyzer.perform_clustering(n_clusters=5)
    print(f"   ✓ Clustered users into {len(clustering_results['cluster_names'])} groups")
    for cluster_id, name in clustering_results['cluster_names'].items():
        count = len(clustering_results['cluster_data'][clustering_results['cluster_data']['cluster'] == cluster_id])
        print(f"      - {name}: {count} users")
    
    # Step 5: Select sample user for detailed analysis
    sample_user = netflix_data['user_id'].iloc[0]
    user_data = netflix_data[netflix_data['user_id'] == sample_user]
    print(f"\n5. Analyzing sample user: {sample_user}")
    print(f"   ✓ User has {len(user_data)} viewing records")
    print(f"   ✓ Top genres: {user_data['genre'].value_counts().head(3).to_dict()}")
    
    # Step 6: Generate psychological profile
    print("\n6. Generating psychological profile...")
    profiler = PsychologicalProfiler()
    psychological_summary = profiler.generate_psychological_summary(user_data)
    
    print("   ✓ McClelland's Theory Analysis:")
    for need, score in psychological_summary['mcclelland_needs'].items():
        print(f"      - {need.title()}: {score:.2f}")
    
    print("   ✓ Maslow's Hierarchy Analysis:")
    for level, score in psychological_summary['maslow_hierarchy'].items():
        print(f"      - {level.replace('_', ' ').title()}: {score:.2f}")
    
    # Step 7: Generate Save the Cat beat sheet
    print("\n7. Generating Save the Cat beat sheet...")
    generator = ScriptGenerator()
    beat_sheet = generator.generate_save_the_cat_beat_sheet(user_data, profiler)
    print(f"   ✓ Generated beat sheet ({len(beat_sheet)} characters)")
    
    # Display sample of beat sheet
    print("\n   Sample beat sheet preview:")
    lines = beat_sheet.split('\n')[:10]
    for line in lines:
        if line.strip():
            print(f"      {line}")
    
    # Step 8: Generate comprehensive script prompt
    print("\n8. Generating script prompt...")
    prompt = generator.generate_comprehensive_prompt(user_data, profiler, 'Short Scene')
    print(f"   ✓ Generated comprehensive prompt ({len(prompt)} characters)")
    
    # Step 9: Display script generation readiness
    print("\n9. Script generation readiness check...")
    print("   ✓ All components successfully initialized")
    print("   ✓ User psychological profile complete")
    print("   ✓ Save the Cat structure ready")
    print("   ✓ Ready for LLM script generation")
    
    print("\n=== TEST COMPLETE - ALL SYSTEMS OPERATIONAL ===")
    print("\nThe AI Movie Script Generator is fully functional with your Netflix engagement data.")
    print("Ready to generate personalized movie scripts based on authentic viewing patterns.")
    
    return {
        'netflix_data': netflix_data,
        'user_profiles': user_profiles,
        'clustering_results': clustering_results,
        'psychological_summary': psychological_summary,
        'beat_sheet': beat_sheet,
        'prompt': prompt
    }

if __name__ == "__main__":
    try:
        results = test_complete_workflow()
        print(f"\nSUCCESS: All {len(results)} components working correctly")
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()