import pandas as pd
import numpy as np
import re
from typing import Dict, List, Tuple

class NetflixEngagementProcessor:
    def __init__(self):
        """Process Netflix engagement report data."""
        self.genre_mapping = {
            # Action/Adventure keywords
            'action': 'Action', 'adventure': 'Adventure', 'superhero': 'Action',
            'spy': 'Action', 'heist': 'Action', 'martial arts': 'Action',
            
            # Drama keywords
            'drama': 'Drama', 'family': 'Drama', 'biographical': 'Drama',
            'historical': 'Drama', 'war': 'Drama', 'legal': 'Drama',
            
            # Comedy keywords
            'comedy': 'Comedy', 'romantic comedy': 'Romance', 'sitcom': 'Comedy',
            'satire': 'Comedy', 'parody': 'Comedy',
            
            # Romance keywords
            'romance': 'Romance', 'romantic': 'Romance', 'love': 'Romance',
            'wedding': 'Romance', 'dating': 'Romance',
            
            # Thriller/Crime keywords
            'thriller': 'Thriller', 'crime': 'Crime', 'mystery': 'Mystery',
            'detective': 'Crime', 'police': 'Crime', 'murder': 'Crime',
            'serial killer': 'Thriller', 'psychological': 'Thriller',
            
            # Horror keywords
            'horror': 'Horror', 'supernatural': 'Horror', 'zombie': 'Horror',
            'vampire': 'Horror', 'ghost': 'Horror', 'haunted': 'Horror',
            
            # Sci-Fi/Fantasy keywords
            'sci-fi': 'Sci-Fi', 'science fiction': 'Sci-Fi', 'fantasy': 'Fantasy',
            'magic': 'Fantasy', 'wizard': 'Fantasy', 'dragon': 'Fantasy',
            'space': 'Sci-Fi', 'alien': 'Sci-Fi', 'time travel': 'Sci-Fi',
            
            # Documentary keywords
            'documentary': 'Documentary', 'true crime': 'Documentary',
            'nature': 'Documentary', 'biography': 'Documentary'
        }
    
    def load_netflix_engagement_data(self, file_path: str) -> pd.DataFrame:
        """Load and process Netflix engagement report data."""
        try:
            # Read TV data
            tv_df = pd.read_excel(file_path, sheet_name='TV', header=4)
            tv_df = tv_df.dropna(how='all')
            tv_df['content_type'] = 'TV'
            
            # Read Film data
            film_df = pd.read_excel(file_path, sheet_name='Film', header=4)
            film_df = film_df.dropna(how='all')
            film_df['content_type'] = 'Film'
            
            # Combine datasets
            combined_df = pd.concat([tv_df, film_df], ignore_index=True)
            
            # Clean and rename columns
            combined_df = self._clean_columns(combined_df)
            
            # Process the data to match expected format
            processed_df = self._process_engagement_data(combined_df)
            
            return processed_df
            
        except Exception as e:
            raise Exception(f"Error processing Netflix engagement data: {str(e)}")
    
    def _clean_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean and rename columns based on content."""
        # Drop the first row if it contains header text
        if len(df) > 0 and 'Title' in str(df.iloc[0].values):
            df = df.drop(df.index[0]).reset_index(drop=True)
        
        # Rename columns based on position and content
        new_columns = []
        for i, col in enumerate(df.columns):
            if i == 0:
                new_columns.append('rank')
            elif i == 1:
                new_columns.append('title')
            elif i == 2:
                new_columns.append('weeks_on_list')
            elif i == 3:
                new_columns.append('hours_viewed')
            elif i == 4:
                new_columns.append('runtime_minutes')
            elif i == 5:
                new_columns.append('views')
            elif i == 6:
                new_columns.append('completion_rate')
            else:
                new_columns.append(col)
        
        df.columns = new_columns
        return df
    
    def _process_engagement_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Convert engagement data to format expected by the analysis pipeline."""
        # Clean the data
        df = df.dropna(subset=['title'])
        df = df[df['title'] != 'Title']  # Remove any remaining header rows
        
        # Extract numeric values from string columns
        df['hours_viewed'] = pd.to_numeric(df['hours_viewed'].astype(str).str.replace(',', ''), errors='coerce')
        df['views'] = pd.to_numeric(df['views'].astype(str).str.replace(',', ''), errors='coerce')
        df['runtime_minutes'] = pd.to_numeric(df['runtime_minutes'].astype(str).str.replace(',', ''), errors='coerce')
        
        # Calculate completion rate if not provided
        if 'completion_rate' not in df.columns or df['completion_rate'].isna().all():
            # Estimate completion rate based on hours viewed vs total runtime
            df['completion_rate'] = np.minimum(100, (df['hours_viewed'] * 60 / df['runtime_minutes'] / df['views']) * 100)
        else:
            df['completion_rate'] = pd.to_numeric(df['completion_rate'].astype(str).str.replace('%', ''), errors='coerce')
        
        # Assign genres based on title keywords
        df['genre'] = df['title'].apply(self._assign_genre)
        
        # Create synthetic user data based on popularity and engagement
        processed_records = []
        
        for _, row in df.iterrows():
            if pd.isna(row['views']) or row['views'] <= 0:
                continue
                
            # Generate synthetic users based on popularity
            num_users = min(int(row['views'] / 1000000), 100)  # Scale down for processing
            
            for user_id in range(1, num_users + 1):
                # Create viewing record
                viewing_time = np.random.normal(row['runtime_minutes'] * 0.7, row['runtime_minutes'] * 0.2)
                viewing_time = max(10, min(viewing_time, row['runtime_minutes']))
                
                completion = np.random.normal(row['completion_rate'], 15)
                completion = max(10, min(completion, 100))
                
                # Rating based on completion and popularity
                base_rating = 2 + (completion / 100 * 2) + (np.log10(row['views']) / 9 * 1)
                rating = np.random.normal(base_rating, 0.5)
                rating = max(1, min(rating, 5))
                
                # Assign demographics
                country = np.random.choice(['United States', 'India', 'United Kingdom', 'Canada', 'Brazil', 'Germany'], 
                                         p=[0.3, 0.2, 0.15, 0.1, 0.15, 0.1])
                age_group = np.random.choice(['18-25', '26-35', '36-45', '46-55', '56+'], 
                                           p=[0.25, 0.3, 0.25, 0.15, 0.05])
                
                processed_records.append({
                    'user_id': f"user_{user_id}_{row.name}",
                    'title': row['title'],
                    'genre': row['genre'],
                    'viewing_time': round(viewing_time, 1),
                    'completion_rate': round(completion, 1),
                    'rating': round(rating, 1),
                    'watch_date': pd.Timestamp.now() - pd.Timedelta(days=np.random.randint(1, 180)),
                    'country': country,
                    'age_group': age_group,
                    'content_type': row['content_type'],
                    'original_views': row['views'],
                    'original_hours': row['hours_viewed']
                })
        
        result_df = pd.DataFrame(processed_records)
        result_df['watch_date'] = result_df['watch_date'].dt.strftime('%Y-%m-%d')
        
        return result_df
    
    def _assign_genre(self, title: str) -> str:
        """Assign genre based on title keywords."""
        title_lower = title.lower()
        
        # Check for genre keywords in title
        for keyword, genre in self.genre_mapping.items():
            if keyword in title_lower:
                return genre
        
        # Special cases based on common Netflix content patterns
        if any(word in title_lower for word in ['love', 'heart', 'kiss', 'wedding']):
            return 'Romance'
        elif any(word in title_lower for word in ['murder', 'killer', 'dead', 'death']):
            return 'Crime'
        elif any(word in title_lower for word in ['funny', 'laugh', 'joke', 'comedy']):
            return 'Comedy'
        elif any(word in title_lower for word in ['dark', 'night', 'shadow', 'evil']):
            return 'Thriller'
        elif any(word in title_lower for word in ['family', 'home', 'life', 'story']):
            return 'Drama'
        elif any(word in title_lower for word in ['world', 'war', 'battle', 'fight']):
            return 'Action'
        
        # Default to Drama for unclassified content
        return 'Drama'
    
    def get_data_summary(self, df: pd.DataFrame) -> Dict:
        """Get summary statistics of the processed data."""
        summary = {
            'total_records': len(df),
            'unique_titles': df['title'].nunique(),
            'unique_users': df['user_id'].nunique(),
            'genre_distribution': df['genre'].value_counts().to_dict(),
            'content_type_distribution': df['content_type'].value_counts().to_dict(),
            'country_distribution': df['country'].value_counts().to_dict(),
            'avg_rating': df['rating'].mean(),
            'avg_completion_rate': df['completion_rate'].mean(),
            'date_range': f"{df['watch_date'].min()} to {df['watch_date'].max()}"
        }
        return summary