# AI Movie Script Generator

## Overview

An AI-powered application that analyzes Netflix viewing data to generate personalized movie scripts using psychological profiling and the Save the Cat screenplay methodology. The system processes Netflix engagement reports, performs user clustering and behavioral analysis, creates psychological profiles based on McClelland's Theory of Needs and Maslow's Hierarchy, and generates complete screenplay beat sheets tailored to viewer preferences.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
**Problem**: Need an interactive interface for data upload, analysis visualization, and script generation.

**Solution**: Streamlit-based web application with custom CSS styling.

**Implementation Details**:
- Single-page application layout with wide configuration
- Custom CSS for enhanced UI (gradient headers, feature boxes, screenplay formatting)
- Interactive visualizations using Plotly (graphs, subplots, charts)
- Real-time data processing and display
- Downloadable script output

**Rationale**: Streamlit provides rapid prototyping with minimal frontend code while supporting complex data visualizations and user interactions.

### Backend Architecture
**Problem**: Process large Netflix engagement datasets and generate psychologically-informed scripts.

**Solution**: Modular Python architecture with specialized components for data processing, analysis, profiling, and generation.

**Core Components**:

1. **Data Processing Layer** (`netflix_data_processor.py`, `netflix_data_processor_old.py`)
   - Processes Netflix engagement Excel reports (TV and Film sheets)
   - Genre classification using keyword mapping
   - Data normalization and synthetic user generation
   - Handles viewing metrics (hours viewed, completion rates, popularity scores)

2. **Analytics Layer** (`data_analyzer.py`)
   - Viewing pattern analysis using pandas aggregations
   - User profiling with feature engineering
   - K-means clustering for viewer segmentation (default 5 clusters)
   - PCA for dimensionality reduction
   - Sklearn-based statistical analysis

3. **Psychological Profiling** (`psychological_profiler.py`)
   - McClelland's Theory of Needs mapping (achievement, power, affiliation)
   - Maslow's Hierarchy of Needs implementation (physiological to self-actualization)
   - Genre-to-psychological-trait conversion
   - Character trait derivation from viewing preferences
   - Weighted scoring system for psychological dimensions

4. **Script Generation** (`script_generator.py`)
   - LLM integration for creative content generation
   - Save the Cat beat sheet structure (15-beat screenplay format)
   - Dual LLM support (OpenAI GPT-4o and Anthropic Claude-3.5-Sonnet)
   - Psychological profile-driven prompt engineering
   - Structured screenplay output formatting

5. **Demo & Testing Scripts** (`demo_script_generator.py`, `final_test_script.py`, `working_script.py`)
   - End-to-end pipeline demonstrations
   - Component integration testing
   - Sample data generation (`sample_data.py`)

**Design Patterns**:
- Class-based organization with single responsibility principle
- Dependency injection for analyzer/profiler/generator components
- Pipeline architecture for data flow
- Factory pattern for synthetic data generation

### Data Storage Solutions
**Problem**: No persistent database required; data flows through in-memory processing.

**Solution**: File-based data ingestion with pandas DataFrames for in-memory operations.

**Implementation**:
- Excel file input (`.xlsx` format) for Netflix engagement reports
- JSON/dict structures for configuration and mapping data
- Pandas DataFrames as primary data structure
- No database dependencies

**Rationale**: Application is stateless with session-based processing; persistent storage unnecessary for current use case.

### Machine Learning Pipeline
**Problem**: Identify viewer archetypes and psychological patterns from viewing behavior.

**Solution**: Unsupervised learning with feature engineering.

**Implementation**:
- StandardScaler for feature normalization
- K-means clustering (configurable clusters, default 5)
- PCA for visualization and dimensionality reduction
- Feature engineering: diversity scores, exploration metrics, genre affinity
- Cluster naming based on dominant characteristics

**Alternatives Considered**: 
- Supervised learning (rejected: no labeled training data)
- DBSCAN clustering (rejected: requires density parameters, K-means more interpretable)

### Authentication & Authorization
**Problem**: API access for LLM services requires secure credential management.

**Solution**: Environment variable-based API key storage.

**Implementation**:
- `OPENAI_API_KEY` for OpenAI GPT-4o access
- `ANTHROPIC_API_KEY` for Anthropic Claude access
- Graceful degradation if keys unavailable
- No user authentication system (single-user application)

## External Dependencies

### Third-Party APIs
1. **OpenAI API**
   - Model: GPT-4o (gpt-4o) - latest as of May 13, 2024
   - Purpose: Script generation and creative writing
   - Library: `openai` Python SDK
   - Authentication: API key via environment variable

2. **Anthropic API**
   - Model: Claude-3.5-Sonnet (claude-3-5-sonnet-20241022) - latest as of October 22, 2024
   - Purpose: Alternative script generation engine
   - Library: `anthropic` Python SDK
   - Authentication: API key via environment variable

### Python Libraries
**Data Processing**:
- `pandas` - DataFrame operations and data manipulation
- `numpy` - Numerical computations
- `openpyxl` (implied) - Excel file reading

**Machine Learning**:
- `scikit-learn` - Clustering (KMeans), scaling (StandardScaler), PCA
- `warnings` - Suppress ML warnings

**Visualization**:
- `plotly` - Interactive charts (express, graph_objects, subplots)
- `matplotlib` (referenced in attached asset)

**Web Framework**:
- `streamlit` - Web application framework

**LLM Integration**:
- `openai` - OpenAI API client
- `anthropic` - Anthropic API client

### Data Sources
- Netflix Engagement Reports (Excel format)
  - File: `What_We_Watched_A_Netflix_Engagement_Report_2024Jan-Jun_1749309553207.xlsx`
  - Sheets: TV, Film
  - Columns: Title, Hours Viewed, Availability, Release Date, Runtime, Views
  - Processing: Header detection, genre extraction, metric normalization

### Configuration Files
- No explicit configuration files
- Hardcoded mappings in profiler classes:
  - Genre-to-McClelland needs mapping
  - Genre-to-Maslow hierarchy mapping
  - Character trait associations
  - Save the Cat beat structure (15 beats)
  - Genre keyword dictionaries