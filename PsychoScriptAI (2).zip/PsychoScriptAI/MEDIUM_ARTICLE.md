# How I Built an AI That Writes Movie Scripts Based on Your Netflix Habits

*Combining Psychology, Machine Learning, and Hollywood Screenwriting to Create Personalized Stories*

---

Have you ever wondered what kind of movie would be written specifically for *you*? Not just a recommendation algorithm suggesting what to watch next, but an entirely original screenplay crafted around your unique psychological profile, derived from your actual viewing patterns?

That's exactly what I built—and the results are fascinating.

## The Idea: Netflix Data Meets Hollywood Structure

The concept started with a simple observation: our Netflix viewing history reveals far more about us than just our entertainment preferences. It's a window into our psychological makeup, our deepest needs, and the stories that resonate with our inner selves.

I wanted to create a system that could:
1. **Analyze viewing patterns** from Netflix engagement data
2. **Build psychological profiles** using established psychological frameworks
3. **Generate original movie scripts** tailored to individual viewer psychology

## The Psychology Behind the Pixels

### McClelland's Theory of Needs

The first psychological framework I implemented was McClelland's Theory of Needs, which identifies three fundamental human motivations:

- **Achievement**: The drive to excel and accomplish goals
- **Power**: The desire to influence and lead others  
- **Affiliation**: The need for social connection and belonging

By analyzing genre preferences and viewing patterns, the system maps content to these core needs. Love action movies and sports documentaries? You likely have high achievement needs. Drawn to political dramas and crime thrillers? Power motivation might be your driver.

### Maslow's Hierarchy of Needs

The second layer uses Maslow's famous pyramid to understand deeper motivations:

- **Physiological** needs (survival content)
- **Safety** needs (security, crime prevention themes)
- **Belongingness** (family, friendship narratives)
- **Esteem** (achievement, recognition stories)
- **Self-Actualization** (documentaries, educational content)

This dual-framework approach creates a nuanced psychological profile that goes beyond simple genre preferences.

## The Technical Stack: Where Data Science Meets Creativity

### Data Processing & Machine Learning

The system processes Netflix engagement reports (those massive Excel files with thousands of viewing records) and performs:

- **K-means clustering** to identify viewer archetypes
- **PCA (Principal Component Analysis)** for dimensionality reduction
- **Feature engineering** to extract diversity scores and exploration metrics

I used Python with:
- **Pandas & NumPy** for data manipulation
- **Scikit-learn** for machine learning
- **Plotly** for interactive visualizations
- **Streamlit** for the web interface

### The Script Generation Engine

Here's where it gets really interesting. The system uses the **Save the Cat** methodology—a proven 15-beat screenplay structure used in Hollywood:

1. Opening Image
2. Theme Stated
3. Set-Up
4. Catalyst
5. Debate
6. Break into Two
7. B Story
8. Fun and Games
9. Midpoint
10. Bad Guys Close In
11. All Is Lost
12. Dark Night of the Soul
13. Break into Three
14. Finale
15. Final Image

I integrated both **OpenAI's GPT-4o** and **Anthropic's Claude-3.5-Sonnet** to generate scripts. The AI receives a detailed prompt containing:

- The user's psychological profile
- Dominant needs and motivations
- Preferred genres and themes
- Character archetypes that resonate
- The Save the Cat beat structure

The result? Professionally formatted screenplays that feel personally tailored.

## Real Results: What the Data Reveals

Testing with real Netflix engagement data showed fascinating patterns:

- **19,188 viewing records** processed from actual user data
- **143 unique user profiles** created with psychological analysis
- **5 distinct viewer clusters** identified, each with unique psychological signatures

One cluster I named "Ambitious Explorers"—high achievement motivation, diverse viewing habits, drawn to challenge-oriented narratives. Another, "Community Seekers," showed high affiliation needs with preferences for ensemble casts and relationship-driven stories.

## The Creative Output

The generated scripts maintain professional formatting with:
- Proper scene headings (INT./EXT.)
- Character names in CAPS
- Industry-standard dialogue formatting
- Cultural sensitivity based on viewing preferences

But more importantly, they tell stories that align with the viewer's psychological makeup. A user with high achievement needs might get a underdog sports drama. Someone with strong affiliation motivation? A heartwarming ensemble piece about found family.

## Ethical Considerations

Building this system raised important questions:

**Privacy**: The tool processes only data you explicitly upload. No data is stored or shared.

**Bias**: I implemented checks to ensure cultural sensitivity and avoid stereotyping based on viewing patterns.

**Authenticity**: While AI-generated, the scripts follow proven storytelling structures and psychological principles.

## What I Learned

1. **Data tells stories**: Viewing patterns are remarkably consistent with psychological theory
2. **Structure matters**: The Save the Cat beats provide crucial scaffolding for AI creativity
3. **Psychology works**: McClelland and Maslow's frameworks effectively map to entertainment preferences
4. **AI is a tool**: The best results come from combining AI capabilities with human frameworks

## Try It Yourself

The project is open source and available on GitHub. You can:
- Upload your own Netflix engagement report
- See your psychological profile visualization
- Generate a script tailored to your viewing psychology

It works with any viewing data in CSV format, so you could theoretically use it with other streaming platforms too.

## The Future

I'm exploring several enhancements:
- **Multiple protagonist scripts** for couples or families
- **Series bible generation** for TV show concepts
- **Integration with other personality frameworks** (Big Five, MBTI)
- **Visual storyboarding** using AI image generation

## Final Thoughts

This project sits at the intersection of data science, psychology, and creative arts. It demonstrates that AI doesn't have to replace human creativity—it can amplify it, making personalized storytelling accessible to everyone.

Your Netflix queue isn't just a list of shows you've watched. It's a psychological portrait, a map of your inner world. And now, it can become a story written just for you.

---

**Want to build something similar?** The code is open source. Check out the GitHub repository and let me know what you create!

**Questions or thoughts?** Drop a comment below. I'd love to hear about your experiences with AI-generated creative content.

---

*Tags: #ArtificialIntelligence #MachineLearning #Screenwriting #Psychology #DataScience #Netflix #CreativeAI #OpenAI #SaveTheCat*
