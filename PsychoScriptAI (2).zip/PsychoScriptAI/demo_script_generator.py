#!/usr/bin/env python3
"""
Complete Demo: Netflix Data to Movie Script Generation
Demonstrates the full pipeline using authentic Netflix engagement data
"""

from netflix_data_processor import NetflixEngagementProcessor
from data_analyzer import NetflixDataAnalyzer
from psychological_profiler import PsychologicalProfiler
from script_generator import ScriptGenerator
import pandas as pd

def demonstrate_complete_pipeline():
    """Complete demonstration of Netflix data to script generation"""
    
    print("AI Movie Script Generator - Complete Demo")
    print("=" * 50)
    
    # Load authentic Netflix engagement data
    print("Loading Netflix engagement data...")
    processor = NetflixEngagementProcessor()
    netflix_data = processor.load_netflix_engagement_data(
        'attached_assets/What_We_Watched_A_Netflix_Engagement_Report_2024Jan-Jun_1749309553207.xlsx'
    )
    print(f"Processed {len(netflix_data)} viewing records from Netflix engagement report")
    
    # Analyze viewing patterns
    print("\nAnalyzing viewing patterns...")
    analyzer = NetflixDataAnalyzer(netflix_data)
    patterns = analyzer.analyze_viewing_patterns()
    user_profiles = analyzer.create_user_profiles()
    clustering_results = analyzer.perform_clustering(n_clusters=5)
    
    print(f"Created profiles for {len(user_profiles)} unique users")
    print(f"Identified {len(clustering_results['cluster_names'])} distinct viewer types:")
    for cluster_id, name in clustering_results['cluster_names'].items():
        count = len(clustering_results['cluster_data'][clustering_results['cluster_data']['cluster'] == cluster_id])
        print(f"  - {name}: {count} users")
    
    # Select user with most diverse viewing pattern
    diversity_scores = user_profiles['exploration_score'].sort_values(ascending=False)
    selected_user = diversity_scores.index[0]
    user_data = netflix_data[netflix_data['user_id'] == selected_user]
    
    print(f"\nSelected user for script generation: {selected_user}")
    print(f"User viewing profile:")
    print(f"  - Total viewing time: {user_data['viewing_time'].sum():.0f} minutes")
    print(f"  - Shows watched: {len(user_data)}")
    print(f"  - Favorite genres: {user_data['genre'].value_counts().head(3).to_dict()}")
    print(f"  - Countries: {user_data['country'].value_counts().to_dict()}")
    
    # Generate psychological profile
    print("\nGenerating psychological profile...")
    profiler = PsychologicalProfiler()
    psychological_summary = profiler.generate_psychological_summary(user_data)
    
    print("McClelland's Needs Analysis:")
    for need, score in psychological_summary['mcclelland_needs'].items():
        interpretation = profiler.interpret_mcclelland_need(need, score)
        print(f"  - {need.title()}: {score:.2f} ({interpretation})")
    
    print("\nMaslow's Hierarchy Analysis:")
    for level, score in psychological_summary['maslow_hierarchy'].items():
        interpretation = profiler.interpret_maslow_level(level, score)
        print(f"  - {level.replace('_', ' ').title()}: {score:.2f}")
    
    print(f"\nCultural Context: {', '.join(psychological_summary['cultural_context'])}")
    
    # Generate Save the Cat beat sheet
    print("\nGenerating Save the Cat beat sheet...")
    generator = ScriptGenerator()
    beat_sheet = generator.generate_save_the_cat_beat_sheet(user_data, profiler)
    
    print("Beat Sheet Structure:")
    print(beat_sheet)
    
    # Generate comprehensive script prompt
    print("\nGenerating comprehensive script prompt...")
    prompt = generator.generate_comprehensive_prompt(user_data, profiler, 'Short Scene')
    
    print("Generated Script Prompt:")
    print("-" * 30)
    print(prompt)
    print("-" * 30)
    
    # Create sample script based on psychological profile (without API)
    print("\nGenerating sample script content...")
    
    # Extract key elements from psychological analysis
    dominant_need = max(psychological_summary['mcclelland_needs'], 
                       key=psychological_summary['mcclelland_needs'].get)
    dominant_maslow = max(psychological_summary['maslow_hierarchy'], 
                         key=psychological_summary['maslow_hierarchy'].get)
    top_genre = user_data['genre'].value_counts().index[0]
    
    # Create sample script based on analysis
    sample_script = generate_sample_script_content(
        dominant_need, dominant_maslow, top_genre, 
        psychological_summary['character_preferences'],
        psychological_summary['cultural_context']
    )
    
    print("Generated Script Preview:")
    print("=" * 40)
    print(sample_script)
    print("=" * 40)
    
    print(f"\nComplete pipeline demonstration successful!")
    print(f"System ready for full script generation with API integration.")
    
    return {
        'netflix_data': netflix_data,
        'user_profiles': user_profiles,
        'selected_user': selected_user,
        'psychological_summary': psychological_summary,
        'beat_sheet': beat_sheet,
        'prompt': prompt,
        'sample_script': sample_script
    }

def generate_sample_script_content(dominant_need, dominant_maslow, genre, character_prefs, cultural_context):
    """Generate sample script content based on psychological analysis"""
    
    # Character archetypes based on psychological needs
    if dominant_need == 'achievement':
        protagonist_type = "ambitious protagonist driven to overcome obstacles"
    elif dominant_need == 'power':
        protagonist_type = "leader who must unite others to face a challenge"
    else:  # affiliation
        protagonist_type = "relationship-focused character seeking connection"
    
    # Conflict based on Maslow's hierarchy
    if dominant_maslow == 'self_actualization':
        central_conflict = "pursuing their true calling despite external pressures"
    elif dominant_maslow == 'esteem':
        central_conflict = "proving their worth to themselves and others"
    elif dominant_maslow == 'belongingness':
        central_conflict = "finding their place in the world"
    else:
        central_conflict = "securing safety and stability for loved ones"
    
    # Genre-specific elements
    genre_elements = {
        'Drama': "emotional stakes and realistic character development",
        'Action': "high-stakes sequences and physical challenges",
        'Comedy': "humor and misunderstandings that lead to growth",
        'Romance': "romantic tension and relationship obstacles",
        'Thriller': "suspense and psychological tension",
        'Horror': "fear and survival instincts",
        'Sci-Fi': "futuristic elements and technological themes",
        'Fantasy': "magical elements and mythical challenges"
    }
    
    genre_element = genre_elements.get(genre, "compelling dramatic elements")
    cultural_theme = cultural_context[0] if cultural_context else "universal human values"
    
    script = f"""FADE IN:

/* OPENING IMAGE - Save the Cat Beat 1 */

INT. MODERN APARTMENT - MORNING

{protagonist_type.upper()} sits by the window, contemplating the city below. The morning light reveals a person at a crossroads, embodying the theme of {central_conflict}.

PROTAGONIST
(to themselves)
Today changes everything.

The camera pulls back to reveal vision boards, plans, and dreams scattered around - visual metaphors for {dominant_need} and the deeper need for {dominant_maslow.replace('_', ' ')}.

/* THEME STATED - Save the Cat Beat 2 */

A knock at the door interrupts their thoughts.

FRIEND (O.S.)
You can't keep running from who you're meant to be.

The protagonist's face reflects internal struggle - this story will explore {cultural_theme} through {genre_element}.

/* CATALYST - Save the Cat Beat 4 */

The protagonist opens the door to find an unexpected visitor carrying news that will force them into action, beginning their journey of {central_conflict}.

VISITOR
(urgently)
We need your help. Everything depends on what you do next.

The protagonist's world shifts - there's no going back now.

/* DEBATE - Save the Cat Beat 5 */

INT. APARTMENT - CONTINUOUS

The protagonist weighs their options, torn between safety and growth, comfort and calling. This internal debate reflects the psychological profile of someone seeking {dominant_maslow.replace('_', ' ')} while driven by {dominant_need}.

PROTAGONIST
(conflicted)
If I do this, everything changes. But if I don't...

They look at a photograph representing what they value most, embodying their core motivation.

/* BREAK INTO TWO - Save the Cat Beat 6 */

The protagonist makes their choice, stepping into the unknown.

PROTAGONIST
(with determination)
I'm in.

FADE TO BLACK.

TITLE CARD: "A story of {central_conflict}, where {genre_element} meet the universal need for {dominant_maslow.replace('_', ' ')}."

FADE OUT.

--- END OF SAMPLE SCENE ---

This sample demonstrates how psychological profiling from Netflix viewing patterns translates into character-driven storytelling using Save the Cat structure and professional screenplay formatting."""

    return script

if __name__ == "__main__":
    try:
        results = demonstrate_complete_pipeline()
        print(f"\nDemo completed successfully - all {len(results)} components generated")
    except Exception as e:
        print(f"Demo error: {e}")
        import traceback
        traceback.print_exc()