# AI Movie Script Generator 🎬

An AI-powered application that analyzes Netflix viewing patterns to generate personalized movie scripts using psychological profiling and professional screenplay methodology.

## Overview

This system processes Netflix viewing data, performs user clustering and behavioral analysis, creates psychological profiles based on McClelland's Theory of Needs and Maslow's Hierarchy, and generates complete screenplay beat sheets tailored to viewer preferences using the Save the Cat methodology.

## Features

- **Netflix Data Analysis**: Process Netflix engagement reports to extract viewing patterns and preferences
- **User Clustering**: K-means clustering to identify viewer archetypes and segments
- **Psychological Profiling**: 
  - McClelland's Theory of Needs (Achievement, Power, Affiliation)
  - Maslow's Hierarchy of Needs (Physiological to Self-Actualization)
- **AI Script Generation**: 
  - Uses OpenAI GPT-4o or Anthropic Claude-3.5-Sonnet
  - Follows Save the Cat 15-beat screenplay structure
  - Professional screenplay formatting
- **Interactive Visualization**: Plotly-powered charts and insights

## How It Works

1. **Data Input**: Upload your Netflix engagement report (Excel format) or CSV viewing data
2. **Analysis**: The system analyzes viewing patterns, genres, and engagement metrics
3. **Profiling**: Creates psychological profiles based on viewing preferences
4. **Clustering**: Groups similar viewers into behavioral clusters
5. **Script Generation**: Generates personalized movie scripts using AI based on your psychological profile

## Screenshots

### 📊 Data Analysis Dashboard
![Data Analysis](attached_assets/stock_images/data_analytics_dashb_71989152.jpg)
*Interactive visualization of viewing patterns, genre preferences, and engagement metrics*

### 🧠 AI-Powered Script Generation
![AI Processing](attached_assets/stock_images/artificial_intellige_72c58c25.jpg)
*Machine learning clustering and psychological profiling in action*

### 🎬 Professional Screenplay Output
![Screenplay Format](attached_assets/stock_images/movie_screenplay_scr_b99e6007.jpg)
*Generated scripts follow industry-standard Save the Cat structure with professional formatting*

## Demo Video

📹 **[Watch the Demo Video](DEMO_VIDEO_DESCRIPTION.md)** - See the complete workflow from data upload to script generation

## Installation

### Prerequisites

- Python 3.8+
- pip package manager

### Setup

1. Clone the repository:
```bash
git clone <your-repo-url>
cd ai-movie-script-generator
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up API keys:
   - OpenAI API key: Set `OPENAI_API_KEY` environment variable
   - Anthropic API key (optional): Set `ANTHROPIC_API_KEY` environment variable

4. Run the application:
```bash
streamlit run app.py --server.port 5000
```

## Usage

### Using Netflix Engagement Report

1. Download your Netflix engagement report from your Netflix account
2. Select "Netflix Engagement Report" option in the app
3. Upload the Excel file
4. Choose a user or cluster to generate a script for
5. Select your preferred AI model (OpenAI or Anthropic)
6. Click "Generate Script" to create your personalized screenplay

### Using CSV Data

1. Prepare a CSV file with columns: user_id, title, genre, viewing_time, watch_date
2. Select "Upload CSV File" option in the app
3. Upload your CSV file
4. Follow the same steps as above

## Project Structure

```
.
├── app.py                          # Main Streamlit application
├── netflix_data_processor.py      # Netflix data processing and parsing
├── data_analyzer.py                # User profiling and clustering
├── psychological_profiler.py      # McClelland & Maslow profiling
├── script_generator.py             # AI script generation with Save the Cat
├── demo_script_generator.py        # Demo script for testing
├── sample_data.py                  # Sample data generation
└── README.md                       # This file
```

## Technologies Used

- **Frontend**: Streamlit
- **Data Processing**: Pandas, NumPy
- **Machine Learning**: Scikit-learn (K-means, PCA, StandardScaler)
- **Visualization**: Plotly
- **AI/LLM**: OpenAI GPT-4o, Anthropic Claude-3.5-Sonnet
- **Data Format**: Excel (openpyxl), CSV

## Psychological Frameworks

### McClelland's Theory of Needs
Maps viewing preferences to three fundamental psychological needs:
- **Achievement**: Action, thriller, sports content
- **Power**: Political dramas, crime, leadership narratives
- **Affiliation**: Romance, family dramas, feel-good content

### Maslow's Hierarchy of Needs
Analyzes content through five levels of human needs:
- **Physiological**: Survival, food-related content
- **Safety**: Crime prevention, security themes
- **Belongingness**: Family, friendship, community
- **Esteem**: Achievement, recognition narratives
- **Self-Actualization**: Documentaries, educational content

### Save the Cat Beat Sheet
Generates scripts following the industry-standard 15-beat structure:
1. Opening Image
2. Theme Stated
3. Set-Up
4. Catalyst
5. Debate
6. Break into Two
7. B Story
8. Fun and Games
9. Midpoint
10. Bad Guys Close In
11. All Is Lost
12. Dark Night of the Soul
13. Break into Three
14. Finale
15. Final Image

## Example Output

The system generates professionally formatted screenplays with:
- Proper scene headings (INT./EXT.)
- Character names in CAPS
- Dialogue formatting
- Action descriptions
- Cultural sensitivity and relevance

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Netflix for viewing data format
- Save the Cat methodology by Blake Snyder
- McClelland's Theory of Needs
- Maslow's Hierarchy of Needs
- OpenAI and Anthropic for AI capabilities

## Disclaimer

This tool is for educational and creative purposes. Please ensure you have the right to use any viewing data you upload, and respect copyright and privacy guidelines.

---

**Note**: You'll need valid API keys with available credits for OpenAI or Anthropic to generate scripts.
