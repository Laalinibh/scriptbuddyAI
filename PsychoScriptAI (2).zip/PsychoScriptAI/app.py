import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from data_analyzer import NetflixDataAnalyzer
from psychological_profiler import PsychologicalProfiler
from script_generator import ScriptGenerator
from sample_data import generate_sample_netflix_data
from netflix_data_processor import NetflixEngagementProcessor

def main():
    st.set_page_config(
        page_title="AI Movie Script Generator",
        page_icon="🎬",
        layout="wide"
    )
    
    # Custom CSS for enhanced styling
    st.markdown("""
    <style>
    .main-header {
        text-align: center;
        padding: 2rem 0;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    .feature-box {
        background-color: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 4px solid #667eea;
        margin: 1rem 0;
    }
    .screenplay {
        font-family: 'Courier New', monospace;
        line-height: 1.6;
        white-space: pre-wrap;
        background-color: #f8f9fa;
        padding: 20px;
        border-radius: 5px;
        border-left: 4px solid #007bff;
        max-height: 600px;
        overflow-y: auto;
    }
    .metric-container {
        background-color: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin: 0.5rem 0;
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown("""
    <div class="main-header">
        <h1>🎬 AI Movie Script Generator</h1>
        <p>Transform Netflix viewing patterns into personalized, psychologically-driven movie scripts</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize session state
    if 'data_processed' not in st.session_state:
        st.session_state.data_processed = False
    if 'netflix_data' not in st.session_state:
        st.session_state.netflix_data = None
    if 'analysis_results' not in st.session_state:
        st.session_state.analysis_results = None
    
    # Sidebar for navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.selectbox(
        "Choose a section:",
        ["Data Upload", "Analysis & Insights", "Psychological Profiling", "Script Generation"]
    )
    
    if page == "Data Upload":
        data_upload_page()
    elif page == "Analysis & Insights":
        analysis_page()
    elif page == "Psychological Profiling":
        psychological_profiling_page()
    elif page == "Script Generation":
        script_generation_page()

def data_upload_page():
    st.header("📊 Data Upload & Processing")
    
    # Option to use sample data, upload CSV, or use Netflix engagement report
    data_option = st.radio(
        "Choose data source:",
        ["Generate Sample Data", "Upload CSV File", "Use Netflix Engagement Report"]
    )
    
    if data_option == "Generate Sample Data":
        st.info("Generate sample Netflix viewing data for demonstration purposes.")
        
        col1, col2 = st.columns(2)
        with col1:
            num_users = st.slider("Number of users", 50, 500, 200)
        with col2:
            num_shows = st.slider("Number of shows/movies", 100, 1000, 500)
        
        if st.button("Generate Sample Data"):
            with st.spinner("Generating sample Netflix data..."):
                sample_data = generate_sample_netflix_data(num_users, num_shows)
                st.session_state.netflix_data = sample_data
                st.session_state.data_processed = True
                st.success(f"Generated sample data with {len(sample_data)} viewing records!")
                st.dataframe(sample_data.head(10))
    
    elif data_option == "Upload CSV File":
        st.info("Upload your Netflix viewing history CSV file.")
        st.markdown("""
        **Expected CSV format:**
        - user_id: Unique identifier for each user
        - title: Name of the show/movie
        - genre: Primary genre
        - viewing_time: Minutes watched
        - completion_rate: Percentage of content watched (0-100)
        - rating: User rating (1-5)
        - watch_date: Date when watched
        - country: User's country
        - age_group: User's age group
        """)
        
        uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
        
        if uploaded_file is not None:
            try:
                netflix_data = pd.read_csv(uploaded_file)
                st.session_state.netflix_data = netflix_data
                st.session_state.data_processed = True
                st.success("Data uploaded successfully!")
                st.dataframe(netflix_data.head(10))
                
                # Display basic statistics
                st.subheader("Data Overview")
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Total Records", len(netflix_data))
                with col2:
                    st.metric("Unique Users", int(netflix_data['user_id'].nunique()))
                with col3:
                    st.metric("Unique Titles", int(netflix_data['title'].nunique()))
                with col4:
                    st.metric("Genres", int(netflix_data['genre'].nunique()))
                    
            except Exception as e:
                st.error(f"Error processing file: {str(e)}")
    
    elif data_option == "Use Netflix Engagement Report":
        st.info("Load and process the provided Netflix engagement report data.")
        
        if st.button("Load Netflix Engagement Data"):
            with st.spinner("Processing Netflix engagement report..."):
                try:
                    processor = NetflixEngagementProcessor()
                    netflix_data = processor.load_netflix_engagement_data(
                        'attached_assets/What_We_Watched_A_Netflix_Engagement_Report_2024Jan-Jun_1749309553207.xlsx'
                    )
                    
                    st.session_state.netflix_data = netflix_data
                    st.session_state.data_processed = True
                    
                    # Show data summary
                    summary = processor.get_data_summary(netflix_data)
                    st.success(f"Successfully processed Netflix engagement data!")
                    
                    # Display summary statistics
                    st.subheader("Netflix Engagement Report Summary")
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Total Records", summary['total_records'])
                    with col2:
                        st.metric("Unique Titles", summary['unique_titles'])
                    with col3:
                        st.metric("Unique Users", summary['unique_users'])
                    with col4:
                        st.metric("Avg Rating", f"{summary['avg_rating']:.1f}")
                    
                    # Show sample data
                    st.subheader("Sample Processed Data")
                    st.dataframe(netflix_data.head(10))
                    
                    # Show genre distribution
                    st.subheader("Content Distribution")
                    col1, col2 = st.columns(2)
                    with col1:
                        st.write("**Genre Distribution:**")
                        for genre, count in summary['genre_distribution'].items():
                            st.write(f"- {genre}: {count}")
                    with col2:
                        st.write("**Content Type Distribution:**")
                        for content_type, count in summary['content_type_distribution'].items():
                            st.write(f"- {content_type}: {count}")
                            
                except Exception as e:
                    st.error(f"Error processing Netflix engagement data: {str(e)}")
                    st.info("Please ensure the Netflix engagement report file is properly formatted.")

def analysis_page():
    st.header("📈 Viewing Pattern Analysis")
    
    if not st.session_state.data_processed or st.session_state.netflix_data is None:
        st.warning("Please upload or generate data first in the Data Upload section.")
        return
    
    data = st.session_state.netflix_data
    analyzer = NetflixDataAnalyzer(data)
    
    # Perform analysis
    with st.spinner("Analyzing viewing patterns..."):
        analysis_results = analyzer.analyze_viewing_patterns()
        clustering_results = analyzer.perform_clustering()
        st.session_state.analysis_results = {
            'patterns': analysis_results,
            'clusters': clustering_results
        }
    
    # Display visualizations
    st.subheader("Genre Preferences")
    genre_dist = data.groupby('genre')['viewing_time'].sum().reset_index()
    fig_genre = px.pie(genre_dist, values='viewing_time', names='genre', 
                       title="Total Viewing Time by Genre")
    st.plotly_chart(fig_genre, use_container_width=True)
    
    # Viewing patterns by country
    st.subheader("Geographic Viewing Patterns")
    country_stats = data.groupby('country').agg({
        'viewing_time': 'mean',
        'completion_rate': 'mean',
        'rating': 'mean'
    }).reset_index()
    
    fig_country = make_subplots(
        rows=1, cols=3,
        subplot_titles=('Avg Viewing Time', 'Avg Completion Rate', 'Avg Rating')
    )
    
    fig_country.add_trace(
        go.Bar(x=country_stats['country'], y=country_stats['viewing_time'], name='Viewing Time'),
        row=1, col=1
    )
    fig_country.add_trace(
        go.Bar(x=country_stats['country'], y=country_stats['completion_rate'], name='Completion Rate'),
        row=1, col=2
    )
    fig_country.add_trace(
        go.Bar(x=country_stats['country'], y=country_stats['rating'], name='Rating'),
        row=1, col=3
    )
    
    fig_country.update_layout(height=400, showlegend=False, title_text="Viewing Metrics by Country")
    st.plotly_chart(fig_country, use_container_width=True)
    
    # Clustering results
    if clustering_results:
        st.subheader("User Clustering Results")
        
        cluster_data = clustering_results['cluster_data']
        fig_cluster = px.scatter(
            cluster_data, x='avg_viewing_time', y='avg_completion_rate',
            color='cluster', size='total_shows_watched',
            title="User Clusters by Viewing Behavior",
            labels={
                'avg_viewing_time': 'Average Viewing Time (minutes)',
                'avg_completion_rate': 'Average Completion Rate (%)'
            }
        )
        st.plotly_chart(fig_cluster, use_container_width=True)
        
        # Cluster characteristics
        st.subheader("Cluster Characteristics")
        cluster_summary = cluster_data.groupby('cluster').agg({
            'avg_viewing_time': 'mean',
            'avg_completion_rate': 'mean',
            'avg_rating': 'mean',
            'total_shows_watched': 'mean'
        }).round(2)
        
        st.dataframe(cluster_summary)

def psychological_profiling_page():
    st.header("🧠 Psychological Profiling")
    
    if not st.session_state.data_processed or st.session_state.netflix_data is None:
        st.warning("Please upload or generate data first in the Data Upload section.")
        return
    
    data = st.session_state.netflix_data
    profiler = PsychologicalProfiler()
    
    # User selection for detailed profiling
    users = data['user_id'].unique()
    selected_user = st.selectbox("Select a user for detailed psychological analysis:", users)
    
    if selected_user:
        user_data = data[data['user_id'] == selected_user]
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("McClelland's Theory of Needs")
            mcclelland_profile = profiler.analyze_mcclelland_needs(user_data)
            
            needs_data = [{'Need': need, 'Score': score} for need, score in mcclelland_profile.items()]
            needs_df = pd.DataFrame(needs_data)
            fig_mcclelland = px.bar(needs_df, x='Need', y='Score', 
                                   title="McClelland's Needs Profile")
            st.plotly_chart(fig_mcclelland, use_container_width=True)
            
            # Display interpretation
            st.write("**Profile Interpretation:**")
            for need, score in mcclelland_profile.items():
                st.write(f"- **{need}**: {score:.2f} - {profiler.interpret_mcclelland_need(need, score)}")
        
        with col2:
            st.subheader("Maslow's Hierarchy of Needs")
            maslow_profile = profiler.analyze_maslow_hierarchy(user_data)
            
            hierarchy_data = [{'Level': level, 'Score': score} for level, score in maslow_profile.items()]
            hierarchy_df = pd.DataFrame(hierarchy_data)
            fig_maslow = px.bar(hierarchy_df, x='Level', y='Score', 
                              title="Maslow's Hierarchy Profile")
            st.plotly_chart(fig_maslow, use_container_width=True)
            
            # Display interpretation
            st.write("**Hierarchy Analysis:**")
            for level, score in maslow_profile.items():
                st.write(f"- **{level}**: {score:.2f} - {profiler.interpret_maslow_level(level, score)}")
        
        # Character traits analysis
        st.subheader("Preferred Character Traits")
        character_traits = profiler.extract_character_preferences(user_data)
        traits_data = [{'Trait': trait, 'Preference': pref} for trait, pref in character_traits.items()]
        traits_df = pd.DataFrame(traits_data)
        st.bar_chart(traits_df.set_index('Trait'))
        
        # Cultural context
        st.subheader("Cultural Context")
        if 'country' in user_data.columns:
            user_country = user_data['country'].iloc[0]
            cultural_context = profiler.get_cultural_context(user_country)
            st.write(f"**User Location**: {user_country}")
            st.write(f"**Cultural Themes**: {', '.join(cultural_context)}")

def script_generation_page():
    st.header("🎭 Script Generation")
    
    if not st.session_state.data_processed or st.session_state.netflix_data is None:
        st.warning("Please upload or generate data first in the Data Upload section.")
        return
    
    data = st.session_state.netflix_data
    profiler = PsychologicalProfiler()
    generator = ScriptGenerator()
    
    # User and parameters selection
    col1, col2 = st.columns(2)
    
    with col1:
        users = data['user_id'].unique()
        selected_user = st.selectbox("Select user for script generation:", users)
        
        script_length = st.select_slider(
            "Script length:",
            options=["Short Scene", "One Act", "Feature Length"],
            value="One Act"
        )
        
        llm_provider = st.selectbox(
            "Choose LLM Provider:",
            ["OpenAI (GPT-4o)", "Anthropic (Claude-3.5-Sonnet)"]
        )
    
    with col2:
        if selected_user:
            user_data = data[data['user_id'] == selected_user]
            
            # Display user summary
            st.subheader("User Profile Summary")
            total_time = user_data['viewing_time'].sum()
            avg_rating = user_data['rating'].mean()
            fav_genre = user_data.groupby('genre')['viewing_time'].sum().idxmax()
            
            st.write(f"**Total Viewing Time**: {total_time:.0f} minutes")
            st.write(f"**Average Rating**: {avg_rating:.1f}/5")
            st.write(f"**Favorite Genre**: {fav_genre}")
            
            if 'country' in user_data.columns:
                st.write(f"**Country**: {user_data['country'].iloc[0]}")
            if 'age_group' in user_data.columns:
                st.write(f"**Age Group**: {user_data['age_group'].iloc[0]}")
    
    if st.button("Generate Script", type="primary"):
        if selected_user:
            user_data = data[data['user_id'] == selected_user]
            
            with st.spinner("Analyzing user profile and generating script..."):
                try:
                    # Generate comprehensive prompt
                    prompt = generator.generate_comprehensive_prompt(user_data, profiler, script_length)
                    
                    # Display the prompt
                    st.subheader("Generated Prompt for LLM")
                    with st.expander("View Generated Prompt", expanded=False):
                        st.code(prompt, language="text")
                    
                    # Generate script using selected LLM
                    if llm_provider == "OpenAI (GPT-4o)":
                        script = generator.generate_script_openai(prompt, script_length)
                    else:
                        script = generator.generate_script_anthropic(prompt, script_length)
                    
                    # Display the generated script with proper formatting
                    st.subheader("Generated Movie Script")
                    st.markdown("---")
                    
                    # Format script with proper screenplay styling
                    formatted_script = script.replace("FADE IN:", "**FADE IN:**")
                    formatted_script = formatted_script.replace("FADE OUT:", "**FADE OUT:**")
                    formatted_script = formatted_script.replace("INT.", "**INT.**")
                    formatted_script = formatted_script.replace("EXT.", "**EXT.**")
                    
                    # Display formatted script
                    
                    st.markdown(f'<div class="screenplay">{formatted_script}</div>', unsafe_allow_html=True)
                    
                    # Download option
                    st.download_button(
                        label="Download Script",
                        data=script,
                        file_name=f"script_user_{selected_user}_{script_length.lower().replace(' ', '_')}.txt",
                        mime="text/plain"
                    )
                    
                except Exception as e:
                    st.error(f"Error generating script: {str(e)}")
                    st.info("Please ensure you have valid API keys set in your environment variables.")
        else:
            st.warning("Please select a user first.")
    
    # Display example prompts
    st.subheader("Example Generated Prompts")
    st.info("""
    **Sample Prompt for Drama-loving User from India:**
    
    "Create a movie script for a 30-year-old viewer from India who primarily watches drama and romance genres. 
    Based on psychological analysis, this user shows high need for affiliation and belongingness. 
    They prefer characters who are loyal, emotional, and family-oriented. 
    
    The script should:
    - Focus on family relationships and community bonds
    - Include cultural elements relevant to Indian audiences
    - Feature emotionally rich character development
    - Incorporate themes of loyalty and sacrifice
    - Use dramatic storytelling with romantic elements
    
    Generate a compelling one-act script that resonates with these preferences."
    """)

if __name__ == "__main__":
    main()
