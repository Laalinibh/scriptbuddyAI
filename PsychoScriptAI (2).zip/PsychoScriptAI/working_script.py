#!/usr/bin/env python3
"""
AI Movie Script Generator - Complete Working Script
Processes Netflix engagement data and generates personalized movie scripts
using psychological profiling and Save the Cat methodology.
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from data_analyzer import NetflixDataAnalyzer
from psychological_profiler import PsychologicalProfiler
from script_generator import ScriptGenerator
from sample_data import generate_sample_netflix_data
from netflix_data_processor import NetflixEngagementProcessor

def main():
    st.set_page_config(
        page_title="AI Movie Script Generator",
        page_icon="🎬",
        layout="wide"
    )
    
    # Enhanced CSS styling
    st.markdown("""
    <style>
    .main-header {
        text-align: center;
        padding: 2rem 0;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    .feature-box {
        background-color: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 4px solid #667eea;
        margin: 1rem 0;
    }
    .screenplay {
        font-family: 'Courier New', monospace;
        line-height: 1.6;
        white-space: pre-wrap;
        background-color: #f8f9fa;
        padding: 20px;
        border-radius: 5px;
        border-left: 4px solid #007bff;
        max-height: 600px;
        overflow-y: auto;
    }
    .metric-container {
        background-color: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin: 0.5rem 0;
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown("""
    <div class="main-header">
        <h1>🎬 AI Movie Script Generator</h1>
        <p>Transform Netflix viewing patterns into personalized, psychologically-driven movie scripts</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize session state
    if 'data_processed' not in st.session_state:
        st.session_state.data_processed = False
    if 'netflix_data' not in st.session_state:
        st.session_state.netflix_data = None
    
    # Sidebar navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.selectbox(
        "Choose a page",
        ["Data Upload", "Analysis", "Psychological Profiling", "Script Generation"]
    )
    
    if page == "Data Upload":
        data_upload_page()
    elif page == "Analysis":
        analysis_page()
    elif page == "Psychological Profiling":
        psychological_profiling_page()
    elif page == "Script Generation":
        script_generation_page()

def data_upload_page():
    st.header("📊 Data Upload & Processing")
    
    st.markdown("""
    <div class="feature-box">
        <h3>Choose Your Data Source</h3>
        <p>Select from three options to begin your personalized script generation:</p>
        <ul>
            <li><strong>Sample Data:</strong> Use pre-generated viewing patterns for testing</li>
            <li><strong>CSV Upload:</strong> Upload your own formatted viewing data</li>
            <li><strong>Netflix Engagement Report:</strong> Process your actual Netflix viewing data</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)
    
    data_option = st.selectbox(
        "Select data source:",
        ["Generate Sample Data", "Upload CSV File", "Use Netflix Engagement Report"]
    )
    
    if data_option == "Generate Sample Data":
        st.info("Generate synthetic Netflix viewing data for demonstration.")
        
        num_users = st.slider("Number of users", 50, 500, 200)
        num_shows = st.slider("Number of shows/movies", 100, 1000, 500)
        
        if st.button("Generate Sample Data"):
            with st.spinner("Generating sample Netflix viewing data..."):
                sample_data = generate_sample_netflix_data(num_users, num_shows)
                st.session_state.netflix_data = sample_data
                st.session_state.data_processed = True
                st.success(f"Generated sample data with {len(sample_data)} viewing records!")
                st.dataframe(sample_data.head(10))
    
    elif data_option == "Upload CSV File":
        st.info("Upload your Netflix viewing history CSV file.")
        st.markdown("""
        **Expected CSV format:**
        - user_id: Unique identifier for each user
        - title: Name of the show/movie
        - genre: Primary genre
        - viewing_time: Minutes watched
        - completion_rate: Percentage of content watched (0-100)
        - rating: User rating (1-5)
        - watch_date: Date when watched
        - country: User's country
        - age_group: User's age group
        """)
        
        uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
        
        if uploaded_file is not None:
            try:
                netflix_data = pd.read_csv(uploaded_file)
                st.session_state.netflix_data = netflix_data
                st.session_state.data_processed = True
                st.success("Data uploaded successfully!")
                st.dataframe(netflix_data.head(10))
                
                # Display basic statistics
                st.subheader("Data Overview")
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Total Records", len(netflix_data))
                with col2:
                    st.metric("Unique Users", int(netflix_data['user_id'].nunique()))
                with col3:
                    st.metric("Unique Titles", int(netflix_data['title'].nunique()))
                with col4:
                    st.metric("Genres", int(netflix_data['genre'].nunique()))
                    
            except Exception as e:
                st.error(f"Error processing file: {str(e)}")
    
    elif data_option == "Use Netflix Engagement Report":
        st.info("Process the provided Netflix engagement report data.")
        
        st.markdown("""
        <div class="feature-box">
            <h4>Netflix Engagement Report Processing</h4>
            <p>This will process your actual Netflix engagement data file, extracting viewing patterns 
            from both TV and Film sheets to create realistic user profiles for script generation.</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.button("Load Netflix Engagement Data"):
            with st.spinner("Processing Netflix engagement report..."):
                try:
                    processor = NetflixEngagementProcessor()
                    netflix_data = processor.load_netflix_engagement_data(
                        'attached_assets/What_We_Watched_A_Netflix_Engagement_Report_2024Jan-Jun_1749309553207.xlsx'
                    )
                    
                    st.session_state.netflix_data = netflix_data
                    st.session_state.data_processed = True
                    
                    st.success(f"Successfully processed Netflix engagement data!")
                    
                    # Show data summary
                    summary = processor.get_data_summary(netflix_data)
                    
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Total Records", summary['total_records'])
                    with col2:
                        st.metric("Unique Users", summary['unique_users'])
                    with col3:
                        st.metric("Unique Titles", summary['unique_titles'])
                    with col4:
                        st.metric("Genres", len(summary['genres']))
                    
                    st.subheader("Sample Data")
                    st.dataframe(netflix_data.head(10))
                    
                    st.subheader("Data Summary")
                    for key, value in summary.items():
                        if key not in ['total_records', 'unique_users', 'unique_titles']:
                            st.write(f"**{key.replace('_', ' ').title()}:** {value}")
                    
                except Exception as e:
                    st.error(f"Error processing Netflix engagement data: {str(e)}")
                    st.info("Please ensure the Netflix engagement report file is properly formatted.")

def analysis_page():
    st.header("📈 Data Analysis & Insights")
    
    if not st.session_state.data_processed or st.session_state.netflix_data is None:
        st.warning("Please upload and process data first on the Data Upload page.")
        return
    
    netflix_data = st.session_state.netflix_data
    
    # Initialize analyzer
    analyzer = NetflixDataAnalyzer(netflix_data)
    
    # Viewing patterns analysis
    st.subheader("Viewing Patterns Analysis")
    with st.spinner("Analyzing viewing patterns..."):
        patterns = analyzer.analyze_viewing_patterns()
    
    # Display genre preferences
    col1, col2 = st.columns(2)
    
    with col1:
        if 'genre_preferences' in patterns:
            fig_genre = px.bar(
                x=patterns['genre_preferences'].index,
                y=patterns['genre_preferences'].values,
                title="Genre Preferences (Total Viewing Time)",
                labels={'x': 'Genre', 'y': 'Total Viewing Time (minutes)'}
            )
            st.plotly_chart(fig_genre, use_container_width=True)
    
    with col2:
        if 'completion_distribution' in patterns:
            fig_completion = px.histogram(
                x=patterns['completion_distribution'].index,
                y=patterns['completion_distribution'].values,
                title="Completion Rate Distribution",
                labels={'x': 'Completion Rate', 'y': 'Number of Views'}
            )
            st.plotly_chart(fig_completion, use_container_width=True)
    
    # User profiles
    st.subheader("User Profiles")
    with st.spinner("Creating user profiles..."):
        user_profiles = analyzer.create_user_profiles()
    
    st.dataframe(user_profiles.head(10))
    
    # Clustering analysis
    st.subheader("User Clustering Analysis")
    n_clusters = st.slider("Number of clusters", 3, 8, 5)
    
    with st.spinner("Performing clustering analysis..."):
        clustering_results = analyzer.perform_clustering(n_clusters)
    
    # Display cluster characteristics
    st.write("**Cluster Characteristics:**")
    st.dataframe(clustering_results['cluster_characteristics'])
    
    # Cluster distribution
    cluster_counts = clustering_results['cluster_data']['cluster'].value_counts().sort_index()
    fig_clusters = px.pie(
        values=cluster_counts.values,
        names=[clustering_results['cluster_names'].get(i, f"Cluster {i}") for i in cluster_counts.index],
        title="User Cluster Distribution"
    )
    st.plotly_chart(fig_clusters, use_container_width=True)

def psychological_profiling_page():
    st.header("🧠 Psychological Profiling")
    
    if not st.session_state.data_processed or st.session_state.netflix_data is None:
        st.warning("Please upload and process data first on the Data Upload page.")
        return
    
    netflix_data = st.session_state.netflix_data
    
    # User selection
    available_users = netflix_data['user_id'].unique()
    selected_user = st.selectbox("Select a user for psychological analysis:", available_users)
    
    if st.button("Generate Psychological Profile"):
        with st.spinner("Analyzing psychological profile..."):
            # Get user data
            user_data = netflix_data[netflix_data['user_id'] == selected_user]
            
            # Initialize profiler
            profiler = PsychologicalProfiler()
            
            # Generate psychological summary
            psychological_summary = profiler.generate_psychological_summary(user_data)
            
            # Display results
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("McClelland's Theory Analysis")
                mcclelland_needs = psychological_summary['mcclelland_needs']
                
                fig_mcclelland = go.Figure(data=[
                    go.Bar(
                        x=list(mcclelland_needs.keys()),
                        y=list(mcclelland_needs.values()),
                        marker_color=['#FF6B6B', '#4ECDC4', '#45B7D1']
                    )
                ])
                fig_mcclelland.update_layout(
                    title="Psychological Needs Analysis",
                    xaxis_title="Need Type",
                    yaxis_title="Score"
                )
                st.plotly_chart(fig_mcclelland, use_container_width=True)
                
                # Display interpretations
                for need, score in mcclelland_needs.items():
                    interpretation = profiler.interpret_mcclelland_need(need, score)
                    st.write(f"**{need.title()}:** {interpretation}")
            
            with col2:
                st.subheader("Maslow's Hierarchy Analysis")
                maslow_hierarchy = psychological_summary['maslow_hierarchy']
                
                fig_maslow = go.Figure(data=[
                    go.Bar(
                        x=list(maslow_hierarchy.keys()),
                        y=list(maslow_hierarchy.values()),
                        marker_color=['#FF9F43', '#A55EEA', '#26DE81', '#FD79A8', '#FDCB6E']
                    )
                ])
                fig_maslow.update_layout(
                    title="Hierarchy of Needs Analysis",
                    xaxis_title="Hierarchy Level",
                    yaxis_title="Score"
                )
                st.plotly_chart(fig_maslow, use_container_width=True)
                
                # Display interpretations
                for level, score in maslow_hierarchy.items():
                    interpretation = profiler.interpret_maslow_level(level, score)
                    st.write(f"**{level.replace('_', ' ').title()}:** {interpretation}")
            
            # Character preferences and cultural context
            st.subheader("Character Preferences & Cultural Context")
            
            col3, col4 = st.columns(2)
            
            with col3:
                st.write("**Preferred Character Traits:**")
                character_prefs = psychological_summary['character_preferences']
                for trait, score in character_prefs.items():
                    st.write(f"- {trait.replace('_', ' ').title()}: {score:.2f}")
            
            with col4:
                st.write("**Cultural Context:**")
                cultural_context = psychological_summary['cultural_context']
                for context in cultural_context:
                    st.write(f"- {context}")
            
            # Store psychological summary for script generation
            st.session_state.psychological_summary = psychological_summary
            st.session_state.selected_user_data = user_data

def script_generation_page():
    st.header("🎬 Script Generation")
    
    if not st.session_state.data_processed or st.session_state.netflix_data is None:
        st.warning("Please upload and process data first on the Data Upload page.")
        return
    
    netflix_data = st.session_state.netflix_data
    
    # User selection for script generation
    available_users = netflix_data['user_id'].unique()
    selected_user = st.selectbox("Select a user for script generation:", available_users)
    
    # Script configuration
    col1, col2 = st.columns(2)
    
    with col1:
        script_length = st.selectbox(
            "Script length:",
            ["Short Scene", "One Act", "Feature Length"]
        )
    
    with col2:
        llm_provider = st.selectbox(
            "LLM Provider:",
            ["OpenAI (GPT-4o)", "Anthropic (Claude)"]
        )
    
    # API Key information
    st.info("Note: You'll need to provide API keys for script generation. The system will prompt you when generating scripts.")
    
    if st.button("Generate Movie Script"):
        with st.spinner("Generating personalized movie script..."):
            try:
                # Get user data
                user_data = netflix_data[netflix_data['user_id'] == selected_user]
                
                # Initialize components
                profiler = PsychologicalProfiler()
                generator = ScriptGenerator()
                
                # Generate comprehensive prompt
                prompt = generator.generate_comprehensive_prompt(user_data, profiler, script_length)
                
                # Display the prompt
                st.subheader("Generated Prompt for LLM")
                with st.expander("View Generated Prompt", expanded=False):
                    st.code(prompt, language="text")
                
                # Generate script using selected LLM
                if llm_provider == "OpenAI (GPT-4o)":
                    script = generator.generate_script_openai(prompt, script_length)
                else:
                    script = generator.generate_script_anthropic(prompt, script_length)
                
                # Display the generated script with proper formatting
                st.subheader("Generated Movie Script")
                st.markdown("---")
                
                # Format script with proper screenplay styling
                formatted_script = script.replace("FADE IN:", "**FADE IN:**")
                formatted_script = formatted_script.replace("FADE OUT:", "**FADE OUT:**")
                formatted_script = formatted_script.replace("INT.", "**INT.**")
                formatted_script = formatted_script.replace("EXT.", "**EXT.**")
                
                # Display formatted script
                st.markdown(f'<div class="screenplay">{formatted_script}</div>', unsafe_allow_html=True)
                
                # Download option
                st.download_button(
                    label="Download Script",
                    data=script,
                    file_name=f"personalized_script_{selected_user}_{script_length.lower().replace(' ', '_')}.txt",
                    mime="text/plain"
                )
                
            except Exception as e:
                st.error(f"Error generating script: {str(e)}")
                if "API key" in str(e):
                    st.info("Please ensure you have provided valid API keys for the selected LLM provider.")

if __name__ == "__main__":
    main()