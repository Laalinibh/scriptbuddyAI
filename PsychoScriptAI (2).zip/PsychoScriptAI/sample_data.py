import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
from typing import List, Dict

def generate_sample_netflix_data(num_users: int = 200, num_shows: int = 500) -> pd.DataFrame:
    """
    Generate sample Netflix viewing data for demonstration purposes.
    
    Args:
        num_users (int): Number of unique users to generate
        num_shows (int): Number of unique shows/movies to generate
        
    Returns:
        pd.DataFrame: Sample Netflix viewing data
    """
    # Set random seed for reproducibility
    np.random.seed(42)
    random.seed(42)
    
    # Define data parameters
    genres = [
        'Action', 'Adventure', 'Comedy', 'Drama', 'Romance', 'Thriller',
        'Horror', 'Documentary', 'Crime', 'Fantasy', 'Sci-Fi', 'Mystery'
    ]
    
    countries = [
        'United States', 'India', 'United Kingdom', 'Canada', 'Australia',
        'Germany', 'France', 'Japan', 'Brazil', 'Mexico', 'South Korea', 'Spain'
    ]
    
    age_groups = ['18-25', '26-35', '36-45', '46-55', '56+']
    
    # Generate show/movie titles with genres
    shows_data = []
    for i in range(num_shows):
        genre = random.choice(genres)
        title_prefixes = {
            'Action': ['Strike Force', 'Combat Zone', 'Maximum', 'Lethal', 'Ultimate'],
            'Adventure': ['Quest for', 'Journey to', 'Lost', 'Hidden', 'Explorer'],
            'Comedy': ['Laugh Track', 'Funny Business', 'Comedy Central', 'Hilarious', 'Witty'],
            'Drama': ['Deep Waters', 'Life Stories', 'Emotional', 'Heart', 'Tears of'],
            'Romance': ['Love Actually', 'Hearts', 'Romantic', 'Forever', 'Endless Love'],
            'Thriller': ['Dark Secrets', 'Suspense', 'Edge of', 'Deadly', 'Final Hour'],
            'Horror': ['Nightmare', 'Terror', 'Haunted', 'Evil', 'Darkness'],
            'Documentary': ['Inside', 'The Truth About', 'Exploring', 'Real Life', 'Behind'],
            'Crime': ['Criminal Minds', 'Law and', 'Detective', 'Murder', 'Justice'],
            'Fantasy': ['Magic Kingdom', 'Enchanted', 'Mystic', 'Dragon', 'Wizard'],
            'Sci-Fi': ['Future World', 'Space', 'Cyber', 'Tech', 'Galaxy'],
            'Mystery': ['Unsolved', 'Secret', 'Hidden Truth', 'Enigma', 'Puzzle']
        }
        
        prefix = random.choice(title_prefixes.get(genre, ['The', 'New', 'Great']))
        suffix = random.choice(['Chronicles', 'Returns', 'Legacy', 'Origins', 'Saga', str(random.randint(1, 10))])
        title = f"{prefix} {suffix}"
        
        shows_data.append({
            'title': title,
            'genre': genre,
            'base_duration': random.randint(45, 180)  # Base duration in minutes
        })
    
    shows_df = pd.DataFrame(shows_data)
    
    # Generate user profiles with psychological tendencies
    users_data = []
    for user_id in range(1, num_users + 1):
        # Assign demographic characteristics
        country = random.choice(countries)
        age_group = random.choice(age_groups)
        
        # Create psychological profile that influences viewing behavior
        achievement_tendency = random.random()
        power_tendency = random.random()
        affiliation_tendency = random.random()
        
        # Normalize psychological tendencies
        total_tendency = achievement_tendency + power_tendency + affiliation_tendency
        achievement_tendency /= total_tendency
        power_tendency /= total_tendency
        affiliation_tendency /= total_tendency
        
        # Genre preferences based on psychological profile
        genre_preferences = {}
        for genre in genres:
            if genre in ['Action', 'Adventure', 'Thriller']:
                preference = achievement_tendency * 0.6 + power_tendency * 0.4
            elif genre in ['Drama', 'Romance', 'Comedy']:
                preference = affiliation_tendency * 0.7 + achievement_tendency * 0.3
            elif genre in ['Horror', 'Crime']:
                preference = power_tendency * 0.5 + achievement_tendency * 0.5
            else:
                preference = (achievement_tendency + power_tendency + affiliation_tendency) / 3
            
            # Add some randomness
            preference += random.random() * 0.3
            genre_preferences[genre] = preference
        
        users_data.append({
            'user_id': user_id,
            'country': country,
            'age_group': age_group,
            'achievement_tendency': achievement_tendency,
            'power_tendency': power_tendency,
            'affiliation_tendency': affiliation_tendency,
            'genre_preferences': genre_preferences
        })
    
    users_df = pd.DataFrame(users_data)
    
    # Generate viewing records
    viewing_records = []
    
    for _, user in users_df.iterrows():
        user_id = user['user_id']
        genre_prefs = user['genre_preferences']
        
        # Determine number of shows this user watched (based on engagement level)
        engagement_level = random.uniform(0.3, 1.0)
        num_shows_watched = int(engagement_level * random.randint(10, 50))
        
        # Generate viewing history for this user
        for _ in range(num_shows_watched):
            # Select show based on genre preference
            preferred_genres = sorted(genre_prefs.items(), key=lambda x: x[1], reverse=True)
            
            # Use weighted selection for genre
            genre_weights = [pref for _, pref in preferred_genres]
            selected_genre = np.random.choice(
                [genre for genre, _ in preferred_genres],
                p=np.array(genre_weights) / sum(genre_weights)
            )
            
            # Select random show from preferred genre
            genre_shows = shows_df[shows_df['genre'] == selected_genre]
            if not genre_shows.empty:
                selected_show = genre_shows.sample(1).iloc[0]
            else:
                selected_show = shows_df.sample(1).iloc[0]
            
            # Generate viewing metrics based on user psychology and show match
            genre_preference_score = genre_prefs[selected_show['genre']]
            
            # Base viewing time influenced by preference and show duration
            base_duration = selected_show['base_duration']
            viewing_time = base_duration * random.uniform(0.2, 1.2) * (0.5 + genre_preference_score)
            viewing_time = max(10, min(viewing_time, base_duration * 1.5))  # Reasonable bounds
            
            # Completion rate based on engagement
            base_completion = 30 + (genre_preference_score * 60)
            completion_rate = base_completion + np.random.normal(0, 15)
            completion_rate = max(5, min(completion_rate, 100))
            
            # Rating based on preference and completion
            base_rating = 2 + (genre_preference_score * 2.5) + (completion_rate / 100 * 1)
            rating = base_rating + np.random.normal(0, 0.5)
            rating = max(1, min(rating, 5))
            
            # Generate random watch date within last year
            days_ago = random.randint(1, 365)
            watch_date = datetime.now() - timedelta(days=days_ago)
            
            viewing_records.append({
                'user_id': user_id,
                'title': selected_show['title'],
                'genre': selected_show['genre'],
                'viewing_time': round(viewing_time, 1),
                'completion_rate': round(completion_rate, 1),
                'rating': round(rating, 1),
                'watch_date': watch_date.strftime('%Y-%m-%d'),
                'country': user['country'],
                'age_group': user['age_group']
            })
    
    # Create final DataFrame
    netflix_data = pd.DataFrame(viewing_records)
    
    # Add some variety and realistic patterns
    # Some users might binge-watch (multiple episodes of same show)
    binge_users = random.sample(list(netflix_data['user_id'].unique()), k=int(num_users * 0.3))
    
    additional_records = []
    for user_id in binge_users:
        user_shows = netflix_data[netflix_data['user_id'] == user_id]['title'].unique()
        if len(user_shows) > 0:
            binge_show = random.choice(user_shows)
            binge_episodes = random.randint(2, 6)
            
            original_record = netflix_data[
                (netflix_data['user_id'] == user_id) & 
                (netflix_data['title'] == binge_show)
            ].iloc[0]
            
            for episode in range(binge_episodes):
                record = original_record.copy()
                record['title'] = f"{binge_show} S1E{episode + 2}"
                record['viewing_time'] *= random.uniform(0.8, 1.2)
                record['completion_rate'] *= random.uniform(0.9, 1.1)
                record['rating'] = max(1, min(5, record['rating'] + random.uniform(-0.5, 0.5)))
                
                additional_records.append(record)
    
    if additional_records:
        additional_df = pd.DataFrame(additional_records)
        netflix_data = pd.concat([netflix_data, additional_df], ignore_index=True)
    
    # Sort by user and date
    netflix_data = netflix_data.sort_values(['user_id', 'watch_date']).reset_index(drop=True)
    
    return netflix_data

def get_sample_user_descriptions() -> Dict[str, str]:
    """
    Get descriptions of different user types in the sample data.
    
    Returns:
        Dict[str, str]: User type descriptions
    """
    return {
        'High Achievement Users': 'Users who prefer action, thriller, and documentary content. They tend to complete shows they start and rate content highly.',
        'High Affiliation Users': 'Users who prefer drama, romance, and comedy. They enjoy character-driven stories and emotional content.',
        'High Power Users': 'Users who prefer crime, horror, and action content. They enjoy stories about control and influence.',
        'Balanced Users': 'Users with mixed preferences who enjoy variety in their content consumption.',
        'Binge Watchers': 'Users who watch multiple episodes of the same show in succession.',
        'Explorers': 'Users who sample many different genres and shows but may not complete everything.',
        'Quality Seekers': 'Users who watch fewer shows but rate them highly and complete most content.',
        'Casual Viewers': 'Users with lower engagement who sample content but may not complete everything.'
    }

def generate_cultural_viewing_patterns() -> Dict[str, Dict]:
    """
    Generate viewing patterns specific to different cultures.
    
    Returns:
        Dict[str, Dict]: Cultural viewing preferences
    """
    return {
        'United States': {
            'preferred_genres': ['Action', 'Comedy', 'Drama'],
            'viewing_characteristics': 'High completion rates, diverse genre preferences',
            'cultural_themes': ['individualism', 'success', 'innovation']
        },
        'India': {
            'preferred_genres': ['Drama', 'Romance', 'Action'],
            'viewing_characteristics': 'Family-oriented content, emotional stories',
            'cultural_themes': ['family', 'tradition', 'spirituality']
        },
        'Japan': {
            'preferred_genres': ['Drama', 'Fantasy', 'Mystery'],
            'viewing_characteristics': 'Quality over quantity, detailed storytelling',
            'cultural_themes': ['honor', 'tradition', 'harmony']
        },
        'United Kingdom': {
            'preferred_genres': ['Comedy', 'Drama', 'Mystery'],
            'viewing_characteristics': 'Preference for wit and complex narratives',
            'cultural_themes': ['humor', 'tradition', 'understatement']
        }
    }
