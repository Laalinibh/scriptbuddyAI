import pandas as pd
import numpy as np
from typing import Dict, List, Tuple

class PsychologicalProfiler:
    def __init__(self):
        """
        Initialize the psychological profiler with McClelland's and Maslow's frameworks.
        """
        # McClelland's Theory of Needs mapping
        self.mcclelland_genre_mapping = {
            'Action': {'achievement': 0.8, 'power': 0.7, 'affiliation': 0.3},
            'Adventure': {'achievement': 0.7, 'power': 0.6, 'affiliation': 0.4},
            'Comedy': {'affiliation': 0.8, 'achievement': 0.3, 'power': 0.2},
            'Drama': {'affiliation': 0.9, 'achievement': 0.4, 'power': 0.3},
            'Romance': {'affiliation': 0.9, 'achievement': 0.2, 'power': 0.2},
            'Thriller': {'achievement': 0.6, 'power': 0.8, 'affiliation': 0.3},
            'Horror': {'power': 0.7, 'achievement': 0.5, 'affiliation': 0.2},
            'Documentary': {'achievement': 0.8, 'power': 0.4, 'affiliation': 0.5},
            'Crime': {'power': 0.8, 'achievement': 0.6, 'affiliation': 0.3},
            'Fantasy': {'achievement': 0.6, 'power': 0.5, 'affiliation': 0.6},
            'Sci-Fi': {'achievement': 0.8, 'power': 0.6, 'affiliation': 0.4},
            'Mystery': {'achievement': 0.7, 'power': 0.5, 'affiliation': 0.4}
        }
        
        # Maslow's Hierarchy mapping
        self.maslow_genre_mapping = {
            'Action': {'physiological': 0.3, 'safety': 0.4, 'belongingness': 0.3, 'esteem': 0.7, 'self_actualization': 0.5},
            'Adventure': {'physiological': 0.4, 'safety': 0.3, 'belongingness': 0.4, 'esteem': 0.8, 'self_actualization': 0.7},
            'Comedy': {'physiological': 0.5, 'safety': 0.6, 'belongingness': 0.8, 'esteem': 0.5, 'self_actualization': 0.4},
            'Drama': {'physiological': 0.4, 'safety': 0.5, 'belongingness': 0.9, 'esteem': 0.6, 'self_actualization': 0.5},
            'Romance': {'physiological': 0.6, 'safety': 0.7, 'belongingness': 0.9, 'esteem': 0.5, 'self_actualization': 0.4},
            'Thriller': {'physiological': 0.3, 'safety': 0.2, 'belongingness': 0.4, 'esteem': 0.7, 'self_actualization': 0.6},
            'Horror': {'physiological': 0.2, 'safety': 0.1, 'belongingness': 0.3, 'esteem': 0.6, 'self_actualization': 0.5},
            'Documentary': {'physiological': 0.3, 'safety': 0.4, 'belongingness': 0.5, 'esteem': 0.6, 'self_actualization': 0.9},
            'Crime': {'physiological': 0.3, 'safety': 0.2, 'belongingness': 0.4, 'esteem': 0.7, 'self_actualization': 0.5},
            'Fantasy': {'physiological': 0.4, 'safety': 0.5, 'belongingness': 0.7, 'esteem': 0.6, 'self_actualization': 0.8},
            'Sci-Fi': {'physiological': 0.3, 'safety': 0.4, 'belongingness': 0.5, 'esteem': 0.7, 'self_actualization': 0.9},
            'Mystery': {'physiological': 0.3, 'safety': 0.4, 'belongingness': 0.5, 'esteem': 0.6, 'self_actualization': 0.7}
        }
        
        # Character traits mapping based on genres
        self.character_traits_mapping = {
            'Action': ['brave', 'determined', 'heroic', 'strong', 'decisive'],
            'Adventure': ['curious', 'brave', 'optimistic', 'resourceful', 'independent'],
            'Comedy': ['humorous', 'lighthearted', 'social', 'optimistic', 'spontaneous'],
            'Drama': ['emotional', 'complex', 'relatable', 'empathetic', 'introspective'],
            'Romance': ['romantic', 'emotional', 'caring', 'passionate', 'loyal'],
            'Thriller': ['intelligent', 'observant', 'cautious', 'resilient', 'analytical'],
            'Horror': ['brave', 'survivor', 'protective', 'determined', 'resourceful'],
            'Documentary': ['intelligent', 'curious', 'analytical', 'factual', 'educational'],
            'Crime': ['intelligent', 'methodical', 'justice-seeking', 'observant', 'determined'],
            'Fantasy': ['imaginative', 'brave', 'magical', 'loyal', 'adventurous'],
            'Sci-Fi': ['intelligent', 'innovative', 'logical', 'futuristic', 'curious'],
            'Mystery': ['analytical', 'patient', 'observant', 'logical', 'persistent']
        }
        
        # Cultural context mapping
        self.cultural_contexts = {
            'United States': ['individualism', 'achievement', 'innovation', 'diversity', 'freedom'],
            'India': ['family_values', 'tradition', 'spirituality', 'community', 'respect_for_elders'],
            'United Kingdom': ['tradition', 'humor', 'politeness', 'class_consciousness', 'understated_emotion'],
            'Canada': ['multiculturalism', 'politeness', 'nature', 'social_harmony', 'inclusivity'],
            'Australia': ['laid_back', 'mateship', 'outdoor_lifestyle', 'humor', 'egalitarianism'],
            'Germany': ['efficiency', 'precision', 'tradition', 'environmental_consciousness', 'direct_communication'],
            'France': ['culture', 'sophistication', 'romance', 'cuisine', 'artistic_expression'],
            'Japan': ['honor', 'tradition', 'harmony', 'respect', 'precision'],
            'Brazil': ['family', 'celebration', 'music', 'warmth', 'community'],
            'Mexico': ['family', 'tradition', 'celebration', 'community', 'spirituality'],
            'South Korea': ['respect', 'education', 'technology', 'community', 'perseverance'],
            'Spain': ['family', 'passion', 'tradition', 'celebration', 'warmth']
        }
    
    def analyze_mcclelland_needs(self, user_data: pd.DataFrame) -> Dict[str, float]:
        """
        Analyze user's psychological needs based on McClelland's Theory.
        
        Args:
            user_data (pd.DataFrame): User's viewing data
            
        Returns:
            Dict[str, float]: Scores for achievement, power, and affiliation needs
        """
        if user_data.empty:
            return {'achievement': 0.0, 'power': 0.0, 'affiliation': 0.0}
        
        # Calculate weighted scores based on viewing time and genre preferences
        total_viewing_time = user_data['viewing_time'].sum()
        
        need_scores = {'achievement': 0.0, 'power': 0.0, 'affiliation': 0.0}
        
        for _, row in user_data.iterrows():
            genre = row['genre']
            viewing_time = row['viewing_time']
            completion_rate = row['completion_rate'] / 100.0  # Normalize to 0-1
            rating = row['rating'] / 5.0  # Normalize to 0-1
            
            # Weight factor based on engagement (viewing time, completion, rating)
            engagement_weight = (viewing_time / total_viewing_time) * completion_rate * rating
            
            if genre in self.mcclelland_genre_mapping:
                genre_needs = self.mcclelland_genre_mapping[genre]
                for need, base_score in genre_needs.items():
                    need_scores[need] += base_score * engagement_weight
        
        # Normalize scores to 0-1 range
        max_possible_score = max(need_scores.values()) if max(need_scores.values()) > 0 else 1
        for need in need_scores:
            need_scores[need] = need_scores[need] / max_possible_score
        
        return need_scores
    
    def analyze_maslow_hierarchy(self, user_data: pd.DataFrame) -> Dict[str, float]:
        """
        Analyze user's needs based on Maslow's Hierarchy.
        
        Args:
            user_data (pd.DataFrame): User's viewing data
            
        Returns:
            Dict[str, float]: Scores for each level of Maslow's hierarchy
        """
        if user_data.empty:
            return {
                'physiological': 0.0, 'safety': 0.0, 'belongingness': 0.0,
                'esteem': 0.0, 'self_actualization': 0.0
            }
        
        total_viewing_time = user_data['viewing_time'].sum()
        
        hierarchy_scores = {
            'physiological': 0.0, 'safety': 0.0, 'belongingness': 0.0,
            'esteem': 0.0, 'self_actualization': 0.0
        }
        
        for _, row in user_data.iterrows():
            genre = row['genre']
            viewing_time = row['viewing_time']
            completion_rate = row['completion_rate'] / 100.0
            rating = row['rating'] / 5.0
            
            engagement_weight = (viewing_time / total_viewing_time) * completion_rate * rating
            
            if genre in self.maslow_genre_mapping:
                genre_hierarchy = self.maslow_genre_mapping[genre]
                for level, base_score in genre_hierarchy.items():
                    hierarchy_scores[level] += base_score * engagement_weight
        
        # Normalize scores
        max_possible_score = max(hierarchy_scores.values()) if max(hierarchy_scores.values()) > 0 else 1
        for level in hierarchy_scores:
            hierarchy_scores[level] = hierarchy_scores[level] / max_possible_score
        
        return hierarchy_scores
    
    def extract_character_preferences(self, user_data: pd.DataFrame) -> Dict[str, float]:
        """
        Extract preferred character traits based on viewing patterns.
        
        Args:
            user_data (pd.DataFrame): User's viewing data
            
        Returns:
            Dict[str, float]: Character trait preferences
        """
        if user_data.empty:
            return {}
        
        trait_scores = {}
        total_viewing_time = user_data['viewing_time'].sum()
        
        for _, row in user_data.iterrows():
            genre = row['genre']
            viewing_time = row['viewing_time']
            completion_rate = row['completion_rate'] / 100.0
            rating = row['rating'] / 5.0
            
            engagement_weight = (viewing_time / total_viewing_time) * completion_rate * rating
            
            if genre in self.character_traits_mapping:
                traits = self.character_traits_mapping[genre]
                for trait in traits:
                    if trait not in trait_scores:
                        trait_scores[trait] = 0.0
                    trait_scores[trait] += engagement_weight
        
        # Normalize and return top traits
        if trait_scores:
            max_score = max(trait_scores.values())
            trait_scores = {trait: score / max_score for trait, score in trait_scores.items()}
            
            # Return top 10 traits
            sorted_traits = dict(sorted(trait_scores.items(), key=lambda x: x[1], reverse=True)[:10])
            return sorted_traits
        
        return {}
    
    def get_cultural_context(self, country: str) -> List[str]:
        """
        Get cultural context for script generation.
        
        Args:
            country (str): User's country
            
        Returns:
            List[str]: Cultural themes and values
        """
        return self.cultural_contexts.get(country, ['universal_themes', 'human_connection', 'personal_growth'])
    
    def interpret_mcclelland_need(self, need: str, score: float) -> str:
        """
        Provide interpretation for McClelland's need scores.
        
        Args:
            need (str): Need type (achievement, power, affiliation)
            score (float): Need score (0-1)
            
        Returns:
            str: Interpretation of the score
        """
        if score >= 0.7:
            level = "High"
        elif score >= 0.4:
            level = "Moderate"
        else:
            level = "Low"
        
        interpretations = {
            'achievement': {
                'High': "Strong drive for personal accomplishment and success",
                'Moderate': "Balanced interest in achieving goals",
                'Low': "Less focused on personal achievement"
            },
            'power': {
                'High': "Desires influence and control over situations",
                'Moderate': "Comfortable with leadership when needed",
                'Low': "Prefers collaborative approaches"
            },
            'affiliation': {
                'High': "Strong need for social connection and belonging",
                'Moderate': "Values relationships but maintains independence",
                'Low': "More independent, less social focus"
            }
        }
        
        return f"{level} - {interpretations.get(need, {}).get(level, 'Score interpretation not available')}"
    
    def interpret_maslow_level(self, level: str, score: float) -> str:
        """
        Provide interpretation for Maslow's hierarchy scores.
        
        Args:
            level (str): Hierarchy level
            score (float): Level score (0-1)
            
        Returns:
            str: Interpretation of the score
        """
        if score >= 0.7:
            intensity = "Strong"
        elif score >= 0.4:
            intensity = "Moderate"
        else:
            intensity = "Low"
        
        interpretations = {
            'physiological': f"{intensity} focus on basic needs and comfort",
            'safety': f"{intensity} emphasis on security and stability",
            'belongingness': f"{intensity} need for love and social connection",
            'esteem': f"{intensity} desire for recognition and self-respect",
            'self_actualization': f"{intensity} drive for personal growth and fulfillment"
        }
        
        return interpretations.get(level, f"{intensity} score for {level}")
    
    def generate_psychological_summary(self, user_data: pd.DataFrame) -> Dict:
        """
        Generate a comprehensive psychological summary for a user.
        
        Args:
            user_data (pd.DataFrame): User's viewing data
            
        Returns:
            Dict: Comprehensive psychological analysis
        """
        if user_data.empty:
            return {}
        
        # Analyze all psychological dimensions
        mcclelland_profile = self.analyze_mcclelland_needs(user_data)
        maslow_profile = self.analyze_maslow_hierarchy(user_data)
        character_traits = self.extract_character_preferences(user_data)
        
        # Determine dominant psychological drivers
        dominant_need = max(mcclelland_profile, key=mcclelland_profile.get)
        dominant_hierarchy = max(maslow_profile, key=maslow_profile.get)
        
        # Get user demographics if available
        country = user_data['country'].iloc[0] if 'country' in user_data.columns else 'Unknown'
        age_group = user_data['age_group'].iloc[0] if 'age_group' in user_data.columns else 'Unknown'
        
        cultural_context = self.get_cultural_context(country)
        
        # Generate viewing behavior insights
        avg_completion = user_data['completion_rate'].mean()
        avg_rating = user_data['rating'].mean()
        genre_diversity = user_data['genre'].nunique()
        total_content = len(user_data)
        
        summary = {
            'mcclelland_profile': mcclelland_profile,
            'maslow_profile': maslow_profile,
            'character_preferences': character_traits,
            'dominant_need': dominant_need,
            'dominant_hierarchy_level': dominant_hierarchy,
            'cultural_context': cultural_context,
            'demographics': {
                'country': country,
                'age_group': age_group
            },
            'viewing_behavior': {
                'avg_completion_rate': round(avg_completion, 2),
                'avg_rating': round(avg_rating, 2),
                'genre_diversity': genre_diversity,
                'total_content_watched': total_content
            }
        }
        
        return summary
