import os
import json
from typing import Dict, List
import pandas as pd
from openai import OpenAI
import anthropic
from anthropic import Anthropic

class ScriptGenerator:
    def __init__(self):
        """
        Initialize the script generator with LLM API clients.
        """
        # Initialize OpenAI client
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        self.openai_api_key = os.getenv("OPENAI_API_KEY", "")
        if self.openai_api_key:
            self.openai_client = OpenAI(api_key=self.openai_api_key)
        else:
            self.openai_client = None
        
        # Initialize Anthropic client
        # the newest Anthropic model is "claude-3-5-sonnet-20241022" which was released October 22, 2024
        self.anthropic_api_key = os.getenv("ANTHROPIC_API_KEY", "")
        if self.anthropic_api_key:
            self.anthropic_client = Anthropic(api_key=self.anthropic_api_key)
        else:
            self.anthropic_client = None
        
        # Save the Cat beat sheet structure
        self.save_the_cat_beats = {
            1: "Opening Image (0-1%)",
            2: "Theme Stated (5%)", 
            3: "Set-Up (1-10%)",
            4: "Catalyst (10%)",
            5: "Debate (10-20%)",
            6: "Break into Two (20%)",
            7: "B Story (22%)",
            8: "Fun and Games (20-50%)",
            9: "Midpoint (50%)",
            10: "Bad Guys Close In (50-75%)",
            11: "All Is Lost (75%)",
            12: "Dark Night of the Soul (75-80%)",
            13: "Break into Three (80%)",
            14: "Finale (80-99%)",
            15: "Final Image (99-100%)"
        }
    
    def generate_save_the_cat_beat_sheet(self, user_data: pd.DataFrame, profiler) -> str:
        """
        Generate a Save the Cat beat sheet based on user's psychological profile.
        
        Args:
            user_data (pd.DataFrame): User's viewing data
            profiler: PsychologicalProfiler instance
            
        Returns:
            str: Save the Cat beat sheet
        """
        # Get psychological analysis
        psychological_summary = profiler.generate_psychological_summary(user_data)
        mcclelland_profile = psychological_summary.get('mcclelland_profile', {})
        maslow_profile = psychological_summary.get('maslow_profile', {})
        character_traits = psychological_summary.get('character_preferences', {})
        cultural_context = psychological_summary.get('cultural_context', [])
        demographics = psychological_summary.get('demographics', {})
        
        # Determine preferred genres and dominant psychological drivers
        genre_preferences = user_data.groupby('genre')['viewing_time'].sum().sort_values(ascending=False)
        primary_genre = str(genre_preferences.index[0]) if len(genre_preferences) > 0 else 'Drama'
        dominant_need = max(mcclelland_profile, key=mcclelland_profile.get) if mcclelland_profile else 'achievement'
        dominant_hierarchy = max(maslow_profile, key=maslow_profile.get) if maslow_profile else 'belongingness'
        
        beat_sheet = []
        beat_sheet.append("SAVE THE CAT BEAT SHEET")
        beat_sheet.append("=" * 50)
        beat_sheet.append(f"Genre: {primary_genre}")
        beat_sheet.append(f"Target Audience: {demographics.get('age_group', 'All Ages')} from {demographics.get('country', 'Global')}")
        beat_sheet.append(f"Psychological Focus: {dominant_need.title()} need, {dominant_hierarchy.replace('_', ' ').title()} level")
        beat_sheet.append("")
        
        # Generate beat-by-beat breakdown
        for beat_num, beat_name in self.save_the_cat_beats.items():
            beat_sheet.append(f"{beat_num}. {beat_name}")
            
            if beat_num == 1:  # Opening Image
                beat_sheet.append(f"   - Visual that represents the {primary_genre.lower()} world")
                beat_sheet.append(f"   - Shows protagonist's current state before transformation")
                
            elif beat_num == 2:  # Theme Stated
                if dominant_need == 'achievement':
                    beat_sheet.append("   - Theme: What does true success mean?")
                elif dominant_need == 'power':
                    beat_sheet.append("   - Theme: Real strength comes from within")
                else:  # affiliation
                    beat_sheet.append("   - Theme: We are stronger together")
                    
            elif beat_num == 3:  # Set-Up
                if character_traits:
                    top_trait = list(character_traits.keys())[0]
                    beat_sheet.append(f"   - Introduce protagonist as {top_trait} character")
                beat_sheet.append(f"   - Establish world rules and cultural context: {', '.join(cultural_context[:2])}")
                
            elif beat_num == 4:  # Catalyst
                if primary_genre in ['Action', 'Thriller']:
                    beat_sheet.append("   - Inciting incident that threatens protagonist's world")
                elif primary_genre in ['Romance', 'Comedy']:
                    beat_sheet.append("   - Meet cute or humorous misunderstanding")
                else:
                    beat_sheet.append("   - Life-changing event that forces protagonist to act")
                    
            elif beat_num == 6:  # Break into Two
                beat_sheet.append(f"   - Protagonist commits to journey addressing {dominant_hierarchy.replace('_', ' ')} needs")
                
            elif beat_num == 8:  # Fun and Games
                beat_sheet.append(f"   - Explore {primary_genre.lower()} elements and {dominant_need} motivation")
                
            elif beat_num == 9:  # Midpoint
                beat_sheet.append("   - False victory or defeat that changes everything")
                beat_sheet.append(f"   - Protagonist's {dominant_need} need is tested")
                
            elif beat_num == 11:  # All Is Lost
                beat_sheet.append(f"   - Protagonist loses what they thought they needed for {dominant_hierarchy.replace('_', ' ')}")
                
            elif beat_num == 14:  # Finale
                beat_sheet.append(f"   - Resolution that satisfies {dominant_need} need and {primary_genre.lower()} expectations")
                beat_sheet.append(f"   - Cultural values ({', '.join(cultural_context[:2])}) are honored")
                
            elif beat_num == 15:  # Final Image
                beat_sheet.append("   - Mirrors opening image but shows transformation")
                
            beat_sheet.append("")
            
        return "\n".join(beat_sheet)

    def generate_comprehensive_prompt(self, user_data: pd.DataFrame, profiler, script_length: str) -> str:
        """
        Generate a comprehensive prompt for LLM based on user's psychological profile using Save the Cat structure.
        
        Args:
            user_data (pd.DataFrame): User's viewing data
            profiler: PsychologicalProfiler instance
            script_length (str): Desired script length
            
        Returns:
            str: Comprehensive prompt for LLM
        """
        # Get psychological analysis
        psychological_summary = profiler.generate_psychological_summary(user_data)
        
        # Extract key information
        mcclelland_profile = psychological_summary.get('mcclelland_profile', {})
        maslow_profile = psychological_summary.get('maslow_profile', {})
        character_traits = psychological_summary.get('character_preferences', {})
        cultural_context = psychological_summary.get('cultural_context', [])
        demographics = psychological_summary.get('demographics', {})
        viewing_behavior = psychological_summary.get('viewing_behavior', {})
        
        # Determine preferred genres
        genre_preferences = user_data.groupby('genre')['viewing_time'].sum().sort_values(ascending=False)
        top_genres = [str(genre) for genre in genre_preferences.head(3).index.tolist()]
        
        # Generate Save the Cat beat sheet
        beat_sheet = self.generate_save_the_cat_beat_sheet(user_data, profiler)
        
        # Build the prompt
        prompt_parts = []
        
        # Introduction and context
        prompt_parts.append(f"Create a {script_length.lower()} movie script using the Save the Cat methodology for a viewer with the following profile:")
        
        # Demographics
        if demographics.get('age_group') != 'Unknown':
            prompt_parts.append(f"- Age Group: {demographics['age_group']}")
        if demographics.get('country') != 'Unknown':
            prompt_parts.append(f"- Location: {demographics['country']}")
        
        # Viewing preferences
        prompt_parts.append(f"- Preferred Genres: {', '.join(top_genres)}")
        prompt_parts.append(f"- Average Content Rating Given: {viewing_behavior.get('avg_rating', 0):.1f}/5")
        prompt_parts.append(f"- Content Completion Rate: {viewing_behavior.get('avg_completion_rate', 0):.1f}%")
        
        # Psychological profile - McClelland's needs
        prompt_parts.append("\nPsychological Profile (McClelland's Theory):")
        dominant_need = max(mcclelland_profile, key=mcclelland_profile.get) if mcclelland_profile else 'achievement'
        for need, score in mcclelland_profile.items():
            level = "High" if score >= 0.7 else "Moderate" if score >= 0.4 else "Low"
            prompt_parts.append(f"- {need.capitalize()} Need: {level} ({score:.2f})")
        
        # Maslow's hierarchy
        prompt_parts.append("\nPsychological Needs (Maslow's Hierarchy):")
        dominant_hierarchy = max(maslow_profile, key=maslow_profile.get) if maslow_profile else 'belongingness'
        for level, score in maslow_profile.items():
            intensity = "Strong" if score >= 0.7 else "Moderate" if score >= 0.4 else "Low"
            prompt_parts.append(f"- {level.replace('_', ' ').title()}: {intensity} ({score:.2f})")
        
        # Character preferences
        if character_traits:
            top_traits = list(character_traits.keys())[:5]
            prompt_parts.append(f"\nPreferred Character Traits: {', '.join(top_traits)}")
        
        # Cultural context
        if cultural_context:
            prompt_parts.append(f"\nCultural Themes to Include: {', '.join(cultural_context)}")
        
        # Include the beat sheet
        prompt_parts.append("\nSAVE THE CAT STRUCTURE TO FOLLOW:")
        prompt_parts.append(beat_sheet)
        
        # Script requirements based on analysis
        prompt_parts.append(f"\nScript Requirements:")
        prompt_parts.append(f"- Primary Focus: Address the viewer's dominant {dominant_need} need and {dominant_hierarchy.replace('_', ' ')} level")
        prompt_parts.append(f"- Genre Style: Incorporate elements from {top_genres[0]} with touches of {', '.join(top_genres[1:])}")
        
        if character_traits:
            prompt_parts.append(f"- Main Character: Should embody traits like {', '.join(list(character_traits.keys())[:3])}")
        
        # Length-specific requirements
        length_requirements = {
            'Short Scene': "Create a compelling 5-10 minute scene focusing on one key Save the Cat beat",
            'One Act': "Develop a complete 20-30 minute one-act following the essential Save the Cat beats",
            'Feature Length': "Structure a full feature-length screenplay following all 15 Save the Cat beats"
        }
        prompt_parts.append(f"- Length: {length_requirements.get(script_length, 'Create an appropriate length script')}")
        
        # Cultural sensitivity
        if demographics.get('country') != 'Unknown':
            prompt_parts.append(f"- Cultural Relevance: Ensure the story resonates with {demographics['country']} cultural values and context")
        
        # Engagement factors
        completion_rate = viewing_behavior.get('avg_completion_rate', 0)
        if completion_rate < 60:
            prompt_parts.append("- Pacing: Use fast-paced storytelling with frequent plot developments to maintain engagement")
        elif completion_rate > 80:
            prompt_parts.append("- Depth: Include rich character development and detailed storytelling")
        
        # Final instructions
        prompt_parts.append("\nGeneration Instructions:")
        prompt_parts.append("- Follow the Save the Cat beat sheet structure provided above")
        prompt_parts.append("- Create original, compelling content that specifically addresses the psychological profile")
        prompt_parts.append("- Include detailed character descriptions, dialogue, and scene directions")
        prompt_parts.append("- Ensure each beat serves the viewer's psychological needs")
        prompt_parts.append("- Use culturally appropriate references and themes")
        prompt_parts.append("- Format as a professional screenplay with proper formatting")
        prompt_parts.append("- Mark each Save the Cat beat clearly in the script")
        
        return "\n".join(prompt_parts)
    
    def generate_script_openai(self, prompt: str, script_length: str) -> str:
        """
        Generate script using OpenAI GPT-4o with proper screenplay formatting.
        
        Args:
            prompt (str): Comprehensive prompt for script generation
            script_length (str): Desired script length
            
        Returns:
            str: Generated movie script in professional format
        """
        if not self.openai_client:
            raise Exception("OpenAI API key not provided. Please set OPENAI_API_KEY environment variable.")
        
        # Determine max tokens based on script length
        token_limits = {
            'Short Scene': 2500,
            'One Act': 5000,
            'Feature Length': 10000
        }
        max_tokens = token_limits.get(script_length, 4000)
        
        # Enhanced system prompt for professional screenplay format
        system_prompt = """You are a professional screenwriter specializing in Save the Cat methodology and psychological storytelling. 

FORMATTING REQUIREMENTS:
- Use proper screenplay format with scene headings (INT./EXT. LOCATION - TIME)
- Character names in ALL CAPS when speaking
- Action lines in present tense, left-aligned
- Dialogue centered with character name above
- Mark each Save the Cat beat clearly with comments
- Use industry-standard formatting conventions

STORYTELLING REQUIREMENTS:
- Follow the provided Save the Cat beat sheet structure
- Address the psychological profile in character motivations
- Include cultural elements naturally in the story
- Create emotionally resonant moments
- Ensure each scene serves the overall narrative arc

Generate a complete, professionally formatted screenplay."""

        try:
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=max_tokens,
                temperature=0.8,
                presence_penalty=0.1,
                frequency_penalty=0.1
            )
            
            script = response.choices[0].message.content or ""
            return self._format_screenplay(script)
            
        except Exception as e:
            raise Exception(f"OpenAI API error: {str(e)}")
    
    def _format_screenplay(self, script: str) -> str:
        """
        Format script with proper screenplay conventions.
        
        Args:
            script (str): Raw script text
            
        Returns:
            str: Formatted screenplay
        """
        if not script:
            return "Error: No script content generated."
            
        lines = script.split('\n')
        formatted_lines = []
        
        for line in lines:
            line = line.strip()
            if not line:
                formatted_lines.append('')
                continue
                
            # Scene headings
            if line.upper().startswith(('INT.', 'EXT.', 'FADE IN:', 'FADE OUT:')):
                formatted_lines.append(line.upper())
            # Character names (all caps lines that are likely speakers)
            elif line.isupper() and len(line.split()) <= 3 and not line.startswith(('INT.', 'EXT.')):
                formatted_lines.append(f"{line}")
            # Save the Cat beat markers
            elif 'BEAT' in line.upper() or any(beat in line.upper() for beat in ['OPENING IMAGE', 'CATALYST', 'MIDPOINT', 'ALL IS LOST', 'FINALE']):
                formatted_lines.append(f"/* {line.upper()} */")
            # Regular dialogue and action
            else:
                formatted_lines.append(line)
        
        return '\n'.join(formatted_lines)
    
    def generate_script_anthropic(self, prompt: str, script_length: str) -> str:
        """
        Generate script using Anthropic Claude with proper screenplay formatting.
        
        Args:
            prompt (str): Comprehensive prompt for script generation
            script_length (str): Desired script length
            
        Returns:
            str: Generated movie script in professional format
        """
        if not self.anthropic_client:
            raise Exception("Anthropic API key not provided. Please set ANTHROPIC_API_KEY environment variable.")
        
        # Determine max tokens based on script length
        token_limits = {
            'Short Scene': 2500,
            'One Act': 5000,
            'Feature Length': 10000
        }
        max_tokens = token_limits.get(script_length, 4000)
        
        # Enhanced system prompt matching OpenAI version
        system_prompt = """You are a professional screenwriter specializing in Save the Cat methodology and psychological storytelling.

FORMATTING REQUIREMENTS:
- Use proper screenplay format with scene headings (INT./EXT. LOCATION - TIME)
- Character names in ALL CAPS when speaking
- Action lines in present tense, left-aligned
- Dialogue centered with character name above
- Mark each Save the Cat beat clearly with comments
- Use industry-standard formatting conventions

STORYTELLING REQUIREMENTS:
- Follow the provided Save the Cat beat sheet structure
- Address the psychological profile in character motivations
- Include cultural elements naturally in the story
- Create emotionally resonant moments
- Ensure each scene serves the overall narrative arc

Generate a complete, professionally formatted screenplay."""
        
        try:
            response = self.anthropic_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=max_tokens,
                temperature=0.8,
                system=system_prompt,
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )
            
            # Extract text content from response
            script_content = ""
            if response.content and len(response.content) > 0:
                first_block = response.content[0]
                if hasattr(first_block, 'text'):
                    script_content = first_block.text
                else:
                    script_content = str(first_block)
            
            return self._format_screenplay(script_content)
            
        except Exception as e:
            raise Exception(f"Anthropic API error: {str(e)}")
    
    def enhance_prompt_with_storytelling_elements(self, base_prompt: str, user_data: pd.DataFrame) -> str:
        """
        Enhance the base prompt with additional storytelling elements.
        
        Args:
            base_prompt (str): Base prompt to enhance
            user_data (pd.DataFrame): User's viewing data
            
        Returns:
            str: Enhanced prompt with storytelling elements
        """
        # Analyze viewing patterns for storytelling preferences
        avg_completion = user_data['completion_rate'].mean()
        avg_rating = user_data['rating'].mean()
        genre_variety = user_data['genre'].nunique()
        
        storytelling_enhancements = []
        
        # Pacing preferences
        if avg_completion < 50:
            storytelling_enhancements.append(
                "- Use rapid pacing with action and conflict introduced early"
            )
            storytelling_enhancements.append(
                "- Include cliffhangers and tension to maintain viewer engagement"
            )
        elif avg_completion > 80:
            storytelling_enhancements.append(
                "- Allow for slower, more contemplative pacing with character development"
            )
            storytelling_enhancements.append(
                "- Include nuanced emotional moments and detailed world-building"
            )
        
        # Quality expectations
        if avg_rating > 4.0:
            storytelling_enhancements.append(
                "- Ensure sophisticated storytelling with layered themes and symbolism"
            )
            storytelling_enhancements.append(
                "- Include unexpected plot twists and complex character motivations"
            )
        
        # Genre mixing preferences
        if genre_variety > 3:
            storytelling_enhancements.append(
                "- Blend multiple genre elements creatively within the narrative"
            )
            storytelling_enhancements.append(
                "- Include varied tonal shifts that keep the audience engaged"
            )
        
        if storytelling_enhancements:
            enhanced_prompt = base_prompt + "\n\nAdditional Storytelling Guidelines:\n" + "\n".join(storytelling_enhancements)
            return enhanced_prompt
        
        return base_prompt
    
    def generate_multiple_concepts(self, user_data: pd.DataFrame, profiler, num_concepts: int = 3) -> List[str]:
        """
        Generate multiple script concepts for the user to choose from.
        
        Args:
            user_data (pd.DataFrame): User's viewing data
            profiler: PsychologicalProfiler instance
            num_concepts (int): Number of concepts to generate
            
        Returns:
            List[str]: List of script concepts
        """
        concepts = []
        
        # Get user's top genres
        genre_preferences = user_data.groupby('genre')['viewing_time'].sum().sort_values(ascending=False)
        top_genres = genre_preferences.head(num_concepts).index.tolist()
        
        for i, genre in enumerate(top_genres):
            # Create genre-specific user data
            genre_data = user_data[user_data['genre'] == genre]
            
            # Generate concept prompt
            concept_prompt = f"""
            Create a brief movie concept (2-3 paragraphs) for a {genre} story that would appeal 
            to a viewer who particularly enjoys this genre. Based on their viewing patterns, 
            they prefer {'high-quality' if user_data['rating'].mean() > 4 else 'entertaining'} content 
            and {'complete' if user_data['completion_rate'].mean() > 75 else 'engaging'} stories.
            
            Include:
            - Core premise and conflict
            - Main character archetype
            - Key themes that would resonate
            - Unique angle or twist
            """
            
            concepts.append(concept_prompt)
        
        return concepts
