import pandas as pd
import numpy as np
from typing import Dict, List
import re
from datetime import datetime, timedelta

class NetflixEngagementProcessor:
    def __init__(self):
        """Process Netflix engagement report data."""
        
        # Genre mapping for content categorization
        self.genre_keywords = {
            'action': 'Action', 'adventure': 'Action', 'superhero': 'Action',
            'drama': 'Drama', 'family': 'Drama', 'biographical': 'Drama',
            'comedy': 'Comedy', 'romantic': 'Romance', 'sitcom': 'Comedy',
            'romance': 'Romance', 'love': 'Romance', 'wedding': 'Romance',
            'thriller': 'Thriller', 'crime': 'Crime', 'mystery': 'Mystery',
            'horror': 'Horror', 'supernatural': 'Horror', 'zombie': 'Horror',
            'sci-fi': 'Sci-Fi', 'fantasy': 'Fantasy', 'space': 'Sci-Fi',
            'documentary': 'Documentary', 'true crime': 'Documentary'
        }
    
    def load_netflix_engagement_data(self, file_path: str) -> pd.DataFrame:
        """Load and process Netflix engagement report data."""
        try:
            # Read TV data with proper header handling
            tv_data = pd.read_excel(file_path, sheet_name='TV', skiprows=4)
            tv_data = tv_data.dropna(how='all')
            
            # Find and set proper column names from the data
            header_row_idx = None
            for idx, row in tv_data.iterrows():
                if 'Title' in str(row.values):
                    header_row_idx = idx
                    break
            
            if header_row_idx is not None:
                # Set column names and remove header rows
                tv_data.columns = tv_data.iloc[header_row_idx].values
                tv_data = tv_data.iloc[header_row_idx + 1:].reset_index(drop=True)
            else:
                # Fallback column assignment
                tv_data.columns = ['rank', 'title', 'available_globally', 'release_date', 'hours_viewed', 'runtime', 'views']
            
            # Clean column names
            tv_data.columns = [str(col).strip() if pd.notna(col) else f'col_{i}' for i, col in enumerate(tv_data.columns)]
            tv_data['content_type'] = 'TV'
            
            # Read Film data similarly
            film_data = pd.read_excel(file_path, sheet_name='Film', skiprows=4)
            film_data = film_data.dropna(how='all')
            
            # Find and set proper column names
            header_row_idx = None
            for idx, row in film_data.iterrows():
                if 'Title' in str(row.values):
                    header_row_idx = idx
                    break
            
            if header_row_idx is not None:
                film_data.columns = film_data.iloc[header_row_idx].values
                film_data = film_data.iloc[header_row_idx + 1:].reset_index(drop=True)
            else:
                film_data.columns = ['rank', 'title', 'available_globally', 'release_date', 'hours_viewed', 'runtime', 'views']
            
            film_data.columns = [str(col).strip() if pd.notna(col) else f'col_{i}' for i, col in enumerate(film_data.columns)]
            film_data['content_type'] = 'Film'
            
            # Combine datasets
            combined_df = pd.concat([tv_data, film_data], ignore_index=True)
            
            # Process to analysis format
            processed_df = self._convert_to_analysis_format(combined_df)
            
            return processed_df
            
        except Exception as e:
            raise Exception(f"Error processing Netflix engagement data: {str(e)}")
    
    def _convert_to_analysis_format(self, df: pd.DataFrame) -> pd.DataFrame:
        """Convert engagement data to format expected by analysis pipeline."""
        # Create synthetic user data based on engagement patterns
        processed_data = []
        
        for _, row in df.iterrows():
            if pd.isna(row.get('Title', row.iloc[1] if len(row) > 1 else None)):
                continue
                
            title = str(row.get('Title', row.iloc[1]))
            views = self._parse_views(row.get('Views', row.iloc[-1]))
            runtime = self._parse_runtime(row.get('Runtime', row.iloc[-2] if len(row) > 5 else '1:30'))
            
            # Generate multiple user records based on popularity
            num_users = min(int(views / 1000000), 200)  # Scale down for processing
            
            for user_id in range(1, num_users + 1):
                # Simulate user viewing behavior
                viewing_time = np.random.uniform(0.3, 1.0) * runtime
                completion_rate = np.random.uniform(30, 95)
                rating = np.random.choice([3, 4, 5], p=[0.2, 0.5, 0.3])
                
                processed_data.append({
                    'user_id': f'user_{user_id}',
                    'title': title,
                    'genre': self._assign_genre(title),
                    'viewing_time': viewing_time,
                    'completion_rate': completion_rate,
                    'rating': rating,
                    'watch_date': self._generate_watch_date(),
                    'country': np.random.choice(['US', 'UK', 'CA', 'AU', 'DE', 'FR'], p=[0.4, 0.15, 0.15, 0.1, 0.1, 0.1]),
                    'age_group': np.random.choice(['18-24', '25-34', '35-44', '45-54', '55+'], p=[0.2, 0.3, 0.25, 0.15, 0.1])
                })
        
        return pd.DataFrame(processed_data)
    
    def _parse_views(self, views_str):
        """Parse view count from string format."""
        if pd.isna(views_str):
            return 1000000
        
        views_str = str(views_str).replace(',', '')
        try:
            return float(views_str)
        except:
            return 1000000
    
    def _parse_runtime(self, runtime_str):
        """Parse runtime from string format (e.g., '1:30' -> 90 minutes)."""
        if pd.isna(runtime_str):
            return 90
        
        runtime_str = str(runtime_str)
        if ':' in runtime_str:
            parts = runtime_str.split(':')
            try:
                hours = int(parts[0])
                minutes = int(parts[1])
                return hours * 60 + minutes
            except:
                return 90
        else:
            try:
                return float(runtime_str)
            except:
                return 90
    
    def _assign_genre(self, title: str) -> str:
        """Assign genre based on title keywords."""
        title_lower = title.lower()
        
        for keyword, genre in self.genre_keywords.items():
            if keyword in title_lower:
                return genre
        
        # Default genre assignment based on title patterns
        if any(word in title_lower for word in ['love', 'heart', 'kiss', 'wedding']):
            return 'Romance'
        elif any(word in title_lower for word in ['kill', 'murder', 'death', 'blood']):
            return 'Thriller'
        elif any(word in title_lower for word in ['funny', 'laugh', 'joke']):
            return 'Comedy'
        elif any(word in title_lower for word in ['fight', 'war', 'battle', 'gun']):
            return 'Action'
        else:
            return 'Drama'
    
    def _generate_watch_date(self):
        """Generate realistic watch date within the report period."""
        start_date = datetime(2024, 1, 1)
        end_date = datetime(2024, 6, 30)
        
        days_diff = (end_date - start_date).days
        random_days = np.random.randint(0, days_diff)
        
        return start_date + timedelta(days=random_days)
    
    def get_data_summary(self, df: pd.DataFrame) -> Dict:
        """Get summary statistics of processed data."""
        return {
            'total_records': len(df),
            'unique_users': df['user_id'].nunique(),
            'unique_titles': df['title'].nunique(),
            'genres': df['genre'].unique().tolist(),
            'countries': df['country'].unique().tolist(),
            'date_range': f"{df['watch_date'].min()} to {df['watch_date'].max()}"
        }