import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import warnings
warnings.filterwarnings('ignore')

class NetflixDataAnalyzer:
    def __init__(self, data):
        """
        Initialize the Netflix data analyzer with viewing data.
        
        Args:
            data (pd.DataFrame): Netflix viewing data
        """
        self.data = data
        self.user_profiles = None
        
    def analyze_viewing_patterns(self):
        """
        Analyze overall viewing patterns and trends.
        
        Returns:
            dict: Analysis results including genre preferences, viewing habits, etc.
        """
        results = {}
        
        # Genre analysis
        genre_stats = self.data.groupby('genre').agg({
            'viewing_time': ['sum', 'mean', 'count'],
            'completion_rate': 'mean',
            'rating': 'mean'
        }).round(2)
        
        # Flatten column names
        genre_stats.columns = ['total_time', 'avg_time', 'total_shows', 'avg_completion', 'avg_rating']
        results['genre_analysis'] = genre_stats.reset_index()
        
        # User viewing behavior
        user_stats = self.data.groupby('user_id').agg({
            'viewing_time': ['sum', 'mean'],
            'completion_rate': 'mean',
            'rating': 'mean',
            'title': 'count'
        }).round(2)
        
        user_stats.columns = ['total_viewing_time', 'avg_viewing_time', 'avg_completion_rate', 'avg_rating', 'total_shows_watched']
        results['user_behavior'] = user_stats.reset_index()
        
        # Time-based patterns (if date column exists)
        if 'watch_date' in self.data.columns:
            try:
                self.data['watch_date'] = pd.to_datetime(self.data['watch_date'])
                self.data['hour'] = self.data['watch_date'].dt.hour
                self.data['day_of_week'] = self.data['watch_date'].dt.day_name()
                
                hourly_patterns = self.data.groupby('hour')['viewing_time'].sum()
                daily_patterns = self.data.groupby('day_of_week')['viewing_time'].sum()
                
                results['hourly_patterns'] = hourly_patterns
                results['daily_patterns'] = daily_patterns
            except:
                pass
        
        # Completion rate analysis
        completion_analysis = self.data.groupby('completion_rate').size()
        results['completion_distribution'] = completion_analysis
        
        # Rating analysis
        rating_analysis = self.data.groupby('rating').size()
        results['rating_distribution'] = rating_analysis
        
        return results
    
    def create_user_profiles(self):
        """
        Create detailed user profiles based on viewing behavior.
        
        Returns:
            pd.DataFrame: User profiles with aggregated metrics
        """
        # Basic viewing metrics - check which columns exist
        agg_dict = {
            'viewing_time': ['sum', 'mean', 'std'],
            'title': 'count'
        }
        
        if 'completion_rate' in self.data.columns:
            agg_dict['completion_rate'] = ['mean', 'std']
            
        if 'rating' in self.data.columns:
            agg_dict['rating'] = ['mean', 'std']
        
        user_profiles = self.data.groupby('user_id').agg(agg_dict).round(2)
        
        # Flatten column names dynamically
        new_columns = []
        for col in user_profiles.columns:
            if col[0] == 'viewing_time':
                if col[1] == 'sum':
                    new_columns.append('total_viewing_time')
                elif col[1] == 'mean':
                    new_columns.append('avg_viewing_time')
                elif col[1] == 'std':
                    new_columns.append('std_viewing_time')
            elif col[0] == 'completion_rate':
                if col[1] == 'mean':
                    new_columns.append('avg_completion_rate')
                elif col[1] == 'std':
                    new_columns.append('std_completion_rate')
            elif col[0] == 'rating':
                if col[1] == 'mean':
                    new_columns.append('avg_rating')
                elif col[1] == 'std':
                    new_columns.append('std_rating')
            elif col[0] == 'title' and col[1] == 'count':
                new_columns.append('total_shows_watched')
            else:
                new_columns.append(f"{col[0]}_{col[1]}")
                
        user_profiles.columns = new_columns
        
        # Genre diversity (number of unique genres watched)
        genre_diversity = self.data.groupby('user_id')['genre'].nunique()
        user_profiles['genre_diversity'] = genre_diversity
        
        # Most watched genre for each user
        user_top_genre = self.data.groupby(['user_id', 'genre'])['viewing_time'].sum().reset_index()
        user_top_genre = user_top_genre.loc[user_top_genre.groupby('user_id')['viewing_time'].idxmax()]
        user_top_genre = user_top_genre.set_index('user_id')['genre']
        user_profiles['top_genre'] = user_top_genre
        
        # Binge-watching tendency (based on consecutive viewing and completion rates)
        if 'avg_completion_rate' in user_profiles.columns:
            user_profiles['binge_tendency'] = (
                user_profiles['avg_completion_rate'] * user_profiles['avg_viewing_time'] / 100
            )
        else:
            user_profiles['binge_tendency'] = user_profiles['avg_viewing_time'] / 60  # Default based on viewing time
        
        # Content explorer vs. focused viewer
        user_profiles['exploration_score'] = (
            user_profiles['genre_diversity'] / user_profiles['total_shows_watched']
        )
        
        # Fill missing values
        user_profiles = user_profiles.fillna(0)
        
        # Add demographic information if available
        if 'country' in self.data.columns:
            user_country = self.data.groupby('user_id')['country'].first()
            user_profiles['country'] = user_country
            
        if 'age_group' in self.data.columns:
            user_age = self.data.groupby('user_id')['age_group'].first()
            user_profiles['age_group'] = user_age
        
        self.user_profiles = user_profiles.reset_index()
        return self.user_profiles
    
    def perform_clustering(self, n_clusters=5):
        """
        Perform user clustering based on viewing behavior.
        
        Args:
            n_clusters (int): Number of clusters to create
            
        Returns:
            dict: Clustering results including cluster assignments and characteristics
        """
        if self.user_profiles is None:
            user_profiles = self.create_user_profiles()
        else:
            user_profiles = self.user_profiles
        
        # Select features for clustering based on available columns
        base_features = ['avg_viewing_time', 'total_shows_watched', 'genre_diversity', 'binge_tendency', 'exploration_score']
        clustering_features = []
        
        for feature in base_features:
            if feature in user_profiles.columns:
                clustering_features.append(feature)
        
        # Add optional features if available
        if 'avg_completion_rate' in user_profiles.columns:
            clustering_features.append('avg_completion_rate')
        if 'avg_rating' in user_profiles.columns:
            clustering_features.append('avg_rating')
        
        # Prepare data for clustering
        X = user_profiles[clustering_features].fillna(0)
        
        # Standardize features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Perform K-means clustering
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init='auto')
        cluster_labels = kmeans.fit_predict(X_scaled)
        
        # Add cluster labels to user profiles
        cluster_data = user_profiles.copy()
        cluster_data['cluster'] = cluster_labels
        
        # Analyze cluster characteristics
        cluster_characteristics = cluster_data.groupby('cluster')[clustering_features].mean().round(2)
        
        # Name clusters based on characteristics
        cluster_names = self._name_clusters(cluster_characteristics)
        cluster_data['cluster_name'] = cluster_data['cluster'].map(cluster_names)
        
        # Calculate cluster sizes
        cluster_sizes = cluster_data['cluster'].value_counts().sort_index()
        
        results = {
            'cluster_data': cluster_data,
            'cluster_characteristics': cluster_characteristics,
            'cluster_names': cluster_names,
            'cluster_sizes': cluster_sizes,
            'scaler': scaler,
            'kmeans_model': kmeans
        }
        
        return results
    
    def _name_clusters(self, cluster_characteristics):
        """
        Assign meaningful names to clusters based on their characteristics.
        
        Args:
            cluster_characteristics (pd.DataFrame): Mean values for each cluster
            
        Returns:
            dict: Mapping of cluster numbers to names
        """
        cluster_names = {}
        
        for cluster_id in cluster_characteristics.index:
            characteristics = cluster_characteristics.loc[cluster_id]
            
            # Determine cluster type based on key metrics
            if characteristics['binge_tendency'] > characteristics['binge_tendency'].mean():
                if characteristics['exploration_score'] > characteristics['exploration_score'].mean():
                    name = "Binge Explorers"
                else:
                    name = "Focused Bingers"
            elif characteristics['exploration_score'] > characteristics['exploration_score'].mean():
                if characteristics['avg_rating'] > characteristics['avg_rating'].mean():
                    name = "Selective Explorers"
                else:
                    name = "Casual Browsers"
            elif characteristics['avg_viewing_time'] > characteristics['avg_viewing_time'].mean():
                name = "Dedicated Viewers"
            else:
                name = "Light Consumers"
            
            cluster_names[cluster_id] = name
        
        return cluster_names
    
    def get_user_similarities(self, user_id, top_n=10):
        """
        Find users with similar viewing patterns to a given user.
        
        Args:
            user_id: Target user ID
            top_n (int): Number of similar users to return
            
        Returns:
            pd.DataFrame: Similar users with similarity scores
        """
        if self.user_profiles is None:
            user_profiles = self.create_user_profiles()
        else:
            user_profiles = self.user_profiles
        
        # Get target user profile
        target_user = user_profiles[user_profiles.index == user_id]
        if target_user.empty:
            return None
        
        # Calculate similarity using cosine similarity on available numerical features
        base_features = ['avg_viewing_time', 'total_shows_watched', 'genre_diversity', 'binge_tendency']
        numerical_features = []
        
        for feature in base_features:
            if feature in user_profiles.columns:
                numerical_features.append(feature)
        
        # Add optional features if available
        if 'avg_completion_rate' in user_profiles.columns:
            numerical_features.append('avg_completion_rate')
        if 'avg_rating' in user_profiles.columns:
            numerical_features.append('avg_rating')
        
        target_vector = target_user[numerical_features].values[0]
        
        similarities = []
        for idx, user in user_profiles.iterrows():
            if idx == user_id:
                continue
                
            user_vector = user[numerical_features].values
            
            # Calculate cosine similarity
            dot_product = np.dot(target_vector, user_vector)
            norm_target = np.linalg.norm(target_vector)
            norm_user = np.linalg.norm(user_vector)
            
            if norm_target > 0 and norm_user > 0:
                similarity = dot_product / (norm_target * norm_user)
                similarities.append({
                    'user_id': user['user_id'],
                    'similarity': similarity,
                    'top_genre': user['top_genre']
                })
        
        # Sort by similarity and return top N
        similarities_df = pd.DataFrame(similarities)
        similarities_df = similarities_df.sort_values('similarity', ascending=False).head(top_n)
        
        return similarities_df
    
    def analyze_content_preferences(self, user_id):
        """
        Analyze detailed content preferences for a specific user.
        
        Args:
            user_id: Target user ID
            
        Returns:
            dict: Detailed content preferences analysis
        """
        user_data = self.data[self.data['user_id'] == user_id]
        
        if user_data.empty:
            return None
        
        preferences = {}
        
        # Genre preferences with detailed metrics
        genre_prefs = user_data.groupby('genre').agg({
            'viewing_time': ['sum', 'mean'],
            'completion_rate': 'mean',
            'rating': 'mean',
            'title': 'count'
        }).round(2)
        genre_prefs.columns = ['total_time', 'avg_time', 'avg_completion', 'avg_rating', 'count']
        preferences['genre_preferences'] = genre_prefs.reset_index()
        
        # Viewing patterns
        preferences['total_viewing_time'] = user_data['viewing_time'].sum()
        preferences['average_session_length'] = user_data['viewing_time'].mean()
        preferences['completion_tendency'] = user_data['completion_rate'].mean()
        preferences['rating_tendency'] = user_data['rating'].mean()
        preferences['content_diversity'] = user_data['genre'].nunique()
        
        # Most and least preferred content
        preferences['most_watched_genre'] = user_data.groupby('genre')['viewing_time'].sum().idxmax()
        preferences['highest_rated_genre'] = user_data.groupby('genre')['rating'].mean().idxmax()
        
        return preferences
